"""
SkyGuard / PS 26073 - AI-ML Based Intelligent Anomaly Detection for AWS
=======================================================================
Member 4 - Module 4 of 4 :  DIAGNOSIS PIPELINE

The orchestrator. Combines every upstream signal into one dashboard-ready
diagnosis:

    ML output (Member 2)  +  Temporal output (Member 3)  +  Multivariate
                                  |
                                  v
                            DIAGNOSIS       (root_cause.py)
                                  |
                                  v
                           EXPLANATION      (explainability.py)
                                  |
                                  v
                            CONFIDENCE      (confidence.py)
                                  |
                                  v
                          RECOMMENDATION    (this file)

Event grouping
--------------
A 30-minute drift at a 5-second sampling rate is ONE fault, not 360 alarms.
The pipeline collapses consecutive samples that share a fault and a channel
into a single incident, so the dashboard shows an operator a handful of
actionable events instead of a wall of rows. Per-sample detail is preserved
underneath for audit.

Usage
-----
    python diagnosis.py --train train_raw.csv \\
                        --ml results/test_predictions.csv \\
                        --temporal member3_anomaly_signals.csv \\
                        --outdir diagnosis_output --evaluate

Only --train and one signal file are strictly required; the pipeline degrades
gracefully if the ML or temporal file is absent.

Outputs
-------
    diagnosis_report.json   full dashboard payload (events + samples + summary)
    diagnosis_summary.csv   one row per sample, for spreadsheets and plots
    events.csv              one row per incident, the operator's work queue

Author : Member 4 (Diagnosis & Explainability)
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from root_cause import (
    COMMUNICATION_FAILURE,
    DRIFT,
    FAULT_TITLE,
    FROZEN_SENSOR,
    GROUND_TRUTH_MAP,
    MULTIVARIATE_ANOMALY,
    NO_FAULT,
    SENSOR_LABEL,
    SENSORS,
    SPIKE,
    UNKNOWN_ANOMALY,
    Baseline,
    RCAConfig,
    RootCauseAnalyzer,
    RootCauseResult,
    SignalRecord,
    load_csv,
    parse_timestamp,
)
from explainability import AnomalyExplainer, Explanation, ShapleyExplainer
from confidence import (
    ConfidenceAssessment,
    ConfidenceScorer,
    SEVERITY_LEVELS,
    calibration_report,
)


# --------------------------------------------------------------------------
# Recommendations
# --------------------------------------------------------------------------

# What to do with the DATA, separately from what to do with the HARDWARE.
# These are different decisions: a drifting sensor still produces data worth
# keeping with a bias flag, while a frozen one produces nothing of value.
QC_ACTION = {
    SPIKE: ("REJECT_SAMPLE", "Discard this sample; interpolate from neighbours."),
    FROZEN_SENSOR: ("REJECT_CHANNEL", "Discard this channel for the whole frozen period."),
    DRIFT: ("FLAG_SUSPECT", "Retain with a bias flag; correct retrospectively after calibration."),
    COMMUNICATION_FAILURE: ("MARK_MISSING", "Record the period as missing; do not interpolate across the gap."),
    MULTIVARIATE_ANOMALY: ("HOLD_FOR_REVIEW", "Withhold from publication until an analyst confirms."),
    UNKNOWN_ANOMALY: ("HOLD_FOR_REVIEW", "Withhold pending analyst review."),
    NO_FAULT: ("ACCEPT", "Publish normally."),
}

FIELD_ACTION = {
    SPIKE: [
        "Inspect sensor cabling, connectors and grounding at the mast.",
        "Check for nearby switching equipment or intermittent power that could inject transients.",
    ],
    FROZEN_SENSOR: [
        "Send a technician to physically inspect the sensing element.",
        "Check for icing, insect nests, salt deposition or a blocked aspirator.",
        "Verify the datalogger is polling the channel rather than caching a stale value.",
    ],
    DRIFT: [
        "Schedule a calibration check against a travelling reference standard.",
        "Compare against the nearest neighbouring AWS to separate instrument drift from a real weather trend.",
        "Review the sensor's age and last calibration date.",
    ],
    COMMUNICATION_FAILURE: [
        "Check station power, modem status and antenna alignment.",
        "Review the datalogger buffer; retrieve any locally stored samples for the gap.",
        "Confirm the backhaul link and server-side ingestion are healthy.",
    ],
    MULTIVARIATE_ANOMALY: [
        "Verify the datalogger channel map against the physical wiring.",
        "Confirm no sensor has been swapped or re-terminated during recent maintenance.",
        "Cross-check the joint reading against a neighbouring station.",
    ],
    UNKNOWN_ANOMALY: [
        "Route to a human analyst; this pattern does not match a known fault signature.",
        "If the pattern repeats, capture it as a new labelled example for model retraining.",
    ],
}


@dataclass
class Recommendation:
    qc_action: str
    qc_note: str
    field_actions: List[str]
    urgency: str
    notify: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "qc_action": self.qc_action,
            "qc_note": self.qc_note,
            "field_actions": self.field_actions,
            "urgency": self.urgency,
            "notify": self.notify,
        }


def build_recommendation(
    result: RootCauseResult,
    assessment: ConfidenceAssessment,
) -> Recommendation:
    """Turn a diagnosis into instructions a duty officer can act on."""
    fault = result.primary.fault
    qc_action, qc_note = QC_ACTION.get(fault, QC_ACTION[UNKNOWN_ANOMALY])
    actions = list(FIELD_ACTION.get(fault, []))

    # A low-confidence diagnosis should trigger verification, not a truck roll.
    if assessment.root_cause_confidence < 0.5 and fault != NO_FAULT:
        actions.insert(
            0,
            "Confirm the diagnosis before dispatching a technician - the named cause "
            "is uncertain and a competing explanation scored close behind.",
        )
        if qc_action in ("REJECT_CHANNEL", "REJECT_SAMPLE"):
            qc_action, qc_note = (
                "FLAG_SUSPECT",
                "Flag rather than discard: the fault is not confidently identified.",
            )

    notify: List[str] = []
    if assessment.severity in ("CRITICAL", "HIGH"):
        notify.append("Station maintenance team")
    if assessment.severity == "CRITICAL":
        notify.append("Duty forecaster - station data may be unusable")
    if fault == DRIFT:
        notify.append("Calibration cell")
    if fault == COMMUNICATION_FAILURE:
        notify.append("Network operations")

    return Recommendation(
        qc_action=qc_action,
        qc_note=qc_note,
        field_actions=actions,
        urgency=assessment.severity_sla,
        notify=notify or ["No notification required"],
    )


# --------------------------------------------------------------------------
# One fully diagnosed sample
# --------------------------------------------------------------------------

@dataclass
class Diagnosis:
    record: SignalRecord
    root_cause: RootCauseResult
    explanation: Explanation
    assessment: ConfidenceAssessment
    recommendation: Recommendation

    @property
    def fault(self) -> str:
        return self.root_cause.primary.fault

    @property
    def is_fault(self) -> bool:
        return self.root_cause.is_fault

    def to_dict(self, full: bool = True) -> Dict[str, Any]:
        record = self.record
        payload: Dict[str, Any] = {
            "index": record.index,
            "timestamp": record.timestamp.isoformat() if record.timestamp else None,
            "readings": {s: record.values.get(s) for s in SENSORS},
            "diagnosis": {
                "fault": self.fault,
                "title": self.explanation.headline,
                "affected_sensors": self.root_cause.primary.affected_sensors,
                "score": round(self.root_cause.primary.score, 3),
            },
            "explanation": {
                "narrative": self.explanation.narrative,
                "why_detected": self.explanation.why_detected,
                "feature_contributions": [
                    c.to_dict() for c in self.explanation.feature_contributions
                ],
                "detector_agreement": self.explanation.detector_agreement,
                "limitations": self.explanation.limitations,
            },
            "confidence": self.assessment.to_dict(),
            "recommendation": self.recommendation.to_dict(),
        }
        if full:
            payload["explanation"]["shap"] = {
                "method": self.explanation.shap_method,
                "values": {
                    c.feature: round(c.shap_value, 4)
                    for c in self.explanation.feature_contributions
                },
                "efficiency_error": self.explanation.shap_efficiency_error,
            }
            payload["technical_trace"] = self.explanation.technical_trace
        if record.true_type:
            payload["ground_truth"] = {
                "type": record.true_type,
                "expected_fault": record.true_fault,
                "correct": record.true_fault == self.fault,
            }
        return payload


# --------------------------------------------------------------------------
# Event grouping
# --------------------------------------------------------------------------

@dataclass
class FaultEvent:
    """A contiguous run of samples sharing one fault: the operator's unit of work."""

    fault: str
    affected_sensors: List[str]
    start: Optional[datetime]
    end: Optional[datetime]
    start_index: int
    end_index: int
    n_samples: int
    peak_severity: str
    peak_severity_score: float
    max_anomaly_confidence: float
    max_root_cause_confidence: float
    representative: Diagnosis

    @property
    def duration_seconds(self) -> float:
        if self.start and self.end:
            return (self.end - self.start).total_seconds()
        return 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fault": self.fault,
            "title": FAULT_TITLE.get(self.fault, self.fault),
            "affected_sensors": self.affected_sensors,
            "affected_sensor_labels": [SENSOR_LABEL.get(s, s) for s in self.affected_sensors],
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
            "duration_seconds": self.duration_seconds,
            "n_samples": self.n_samples,
            "severity": self.peak_severity,
            "severity_score": round(self.peak_severity_score, 1),
            "anomaly_confidence": round(self.max_anomaly_confidence, 3),
            "root_cause_confidence": round(self.max_root_cause_confidence, 3),
            "narrative": self.representative.explanation.narrative,
            "why_detected": self.representative.explanation.why_detected,
            "recommendation": self.representative.recommendation.to_dict(),
            "limitations": self.representative.explanation.limitations,
        }


def group_events(diagnoses: List[Diagnosis], max_gap: int = 3) -> List[FaultEvent]:
    """
    Collapse consecutive same-fault samples into incidents.

    `max_gap` tolerates short healthy stretches inside one ongoing fault - an
    intermittent sensor that recovers for two samples is still one incident.
    """
    events: List[FaultEvent] = []
    current: List[Diagnosis] = []
    gap = 0

    def flush(batch: List[Diagnosis]) -> None:
        if not batch:
            return
        peak = max(batch, key=lambda d: d.assessment.severity_score)
        sensors = sorted({s for d in batch for s in d.root_cause.primary.affected_sensors})
        events.append(FaultEvent(
            fault=batch[0].fault,
            affected_sensors=sensors,
            start=batch[0].record.timestamp,
            end=batch[-1].record.timestamp,
            start_index=batch[0].record.index,
            end_index=batch[-1].record.index,
            n_samples=len(batch),
            peak_severity=peak.assessment.severity,
            peak_severity_score=peak.assessment.severity_score,
            max_anomaly_confidence=max(d.assessment.anomaly_confidence for d in batch),
            max_root_cause_confidence=max(d.assessment.root_cause_confidence for d in batch),
            representative=peak,
        ))

    for diag in diagnoses:
        if not diag.is_fault:
            if current:
                gap += 1
                if gap > max_gap:
                    flush(current)
                    current, gap = [], 0
            continue

        if current and diag.fault == current[-1].fault:
            current.append(diag)
            gap = 0
        else:
            flush(current)
            current, gap = [diag], 0

    flush(current)
    return events


# --------------------------------------------------------------------------
# Input merging
# --------------------------------------------------------------------------

def merge_sources(
    ml_path: Optional[str],
    temporal_path: Optional[str],
) -> List[SignalRecord]:
    """
    Join the ML and temporal outputs on `datetime`.

    Falls back to positional joining if timestamps do not line up, and reports
    what it did rather than silently producing half-empty records.
    """
    if not ml_path and not temporal_path:
        raise SystemExit("Provide at least one of --ml or --temporal.")

    if ml_path and not temporal_path:
        rows = load_csv(ml_path)
        print(f"  Using ML output only ({len(rows)} rows); temporal signals absent.")
        return [SignalRecord.from_dict(r, i) for i, r in enumerate(rows)]

    if temporal_path and not ml_path:
        rows = load_csv(temporal_path)
        print(f"  Using temporal output only ({len(rows)} rows); ML signals absent.")
        return [SignalRecord.from_dict(r, i) for i, r in enumerate(rows)]

    ml_rows = load_csv(ml_path)
    temporal_rows = load_csv(temporal_path)

    ml_by_time: Dict[str, Dict[str, Any]] = {}
    for row in ml_rows:
        key = str(row.get("datetime", "")).strip()
        if key:
            ml_by_time[key] = row

    merged: List[SignalRecord] = []
    matched = 0
    for i, row in enumerate(temporal_rows):
        key = str(row.get("datetime", "")).strip()
        combined = dict(row)
        ml_row = ml_by_time.get(key)
        if ml_row is None and i < len(ml_rows):
            ml_row = ml_rows[i]  # positional fallback
        else:
            matched += 1
        if ml_row:
            for field_name in ("decision_score", "predicted_anomaly", "anomaly_score",
                               "predicted_status"):
                if field_name in ml_row:
                    combined[field_name] = ml_row[field_name]
        merged.append(SignalRecord.from_dict(combined, i))

    print(f"  Merged {len(merged)} samples "
          f"({matched} joined on timestamp, {len(merged) - matched} positionally).")
    return merged


# --------------------------------------------------------------------------
# The pipeline
# --------------------------------------------------------------------------

class DiagnosisPipeline:
    def __init__(
        self,
        baseline: Baseline,
        config: Optional[RCAConfig] = None,
        background: Optional[List[Dict[str, float]]] = None,
    ):
        self.baseline = baseline
        self.analyzer = RootCauseAnalyzer(baseline, config)
        self.explainer = AnomalyExplainer(
            baseline, ShapleyExplainer(baseline, background=background)
        )
        self.scorer = ConfidenceScorer(baseline)

    def run(self, records: List[SignalRecord]) -> List[Diagnosis]:
        results = self.analyzer.analyze_stream(records)

        diagnoses: List[Diagnosis] = []
        for i, result in enumerate(results):
            explanation = self.explainer.explain(result)
            assessment = self.scorer.assess(result, results[:i])
            recommendation = build_recommendation(result, assessment)
            diagnoses.append(Diagnosis(
                record=result.record,
                root_cause=result,
                explanation=explanation,
                assessment=assessment,
                recommendation=recommendation,
            ))
        return diagnoses

    # -- reporting ----------------------------------------------------------

    def summary(self, diagnoses: List[Diagnosis], events: List[FaultEvent]) -> Dict[str, Any]:
        faults = [d for d in diagnoses if d.is_fault]
        fault_counts = Counter(d.fault for d in faults)
        severity_counts = Counter(d.assessment.severity for d in faults)

        health = 100.0 * (1 - len(faults) / max(len(diagnoses), 1))

        return {
            "samples_analysed": len(diagnoses),
            "samples_flagged": len(faults),
            "flagged_pct": round(100.0 * len(faults) / max(len(diagnoses), 1), 1),
            "station_health_pct": round(health, 1),
            "distinct_events": len(events),
            "fault_breakdown": dict(fault_counts),
            "severity_breakdown": {
                level: severity_counts.get(level, 0) for level in reversed(SEVERITY_LEVELS)
            },
            "open_actions": len([e for e in events if e.peak_severity in ("CRITICAL", "HIGH")]),
            "multivariate_calibration": self.analyzer.calibration_note,
            "shap_method": self.explainer.shapley.method,
            "period_start": (diagnoses[0].record.timestamp.isoformat()
                             if diagnoses and diagnoses[0].record.timestamp else None),
            "period_end": (diagnoses[-1].record.timestamp.isoformat()
                           if diagnoses and diagnoses[-1].record.timestamp else None),
        }

    def evaluate(self, diagnoses: List[Diagnosis]) -> Optional[Dict[str, Any]]:
        """Score the pipeline against ground truth, when labels are present."""
        labelled = [d for d in diagnoses if d.record.truly_anomalous is not None]
        if not labelled:
            return None

        tp = sum(1 for d in labelled if d.record.truly_anomalous and d.is_fault)
        fp = sum(1 for d in labelled if not d.record.truly_anomalous and d.is_fault)
        fn = sum(1 for d in labelled if d.record.truly_anomalous and not d.is_fault)
        tn = sum(1 for d in labelled if not d.record.truly_anomalous and not d.is_fault)

        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-9)

        detected = [d for d in labelled if d.is_fault]
        correct_cause = sum(1 for d in detected if d.record.true_fault == d.fault)

        matrix: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        for d in labelled:
            matrix[d.record.true_type or "unknown"][d.fault] += 1

        truths = [d.record.truly_anomalous for d in labelled]
        assessments = [d.assessment for d in labelled]

        return {
            "detection": {
                "precision": round(precision, 3),
                "recall": round(recall, 3),
                "f1": round(f1, 3),
                "accuracy": round((tp + tn) / max(len(labelled), 1), 3),
                "confusion": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
            },
            "root_cause": {
                "correct": correct_cause,
                "of_detected": len(detected),
                "accuracy": round(correct_cause / max(len(detected), 1), 3),
            },
            "fault_matrix": {k: dict(v) for k, v in matrix.items()},
            "confidence_calibration": calibration_report(assessments, truths),
        }


# --------------------------------------------------------------------------
# Console report
# --------------------------------------------------------------------------

def print_report(summary: Dict[str, Any], events: List[FaultEvent],
                 evaluation: Optional[Dict[str, Any]]) -> None:
    line = "=" * 78
    print(f"\n{line}\nSKYGUARD - AWS STATION DIAGNOSIS REPORT\n{line}")
    print(f"Period            : {summary['period_start']}  ->  {summary['period_end']}")
    print(f"Samples analysed  : {summary['samples_analysed']}")
    print(f"Samples flagged   : {summary['samples_flagged']} ({summary['flagged_pct']}%)")
    print(f"Station health    : {summary['station_health_pct']}%")
    print(f"Distinct incidents: {summary['distinct_events']}  "
          f"({summary['open_actions']} needing action)")

    print(f"\nSeverity breakdown")
    for level, count in summary["severity_breakdown"].items():
        if count:
            print(f"  {level:<10} {count:>5}")

    print(f"\nFault breakdown")
    for fault, count in sorted(summary["fault_breakdown"].items(), key=lambda kv: -kv[1]):
        print(f"  {FAULT_TITLE.get(fault, fault):<36} {count:>5}")

    actionable = [e for e in events if e.peak_severity in ("CRITICAL", "HIGH")]
    actionable.sort(key=lambda e: -e.peak_severity_score)

    print(f"\n{line}\nTOP INCIDENTS\n{line}")
    for event in actionable[:5]:
        when = event.start.strftime("%d %b %H:%M:%S") if event.start else "?"
        mins = event.duration_seconds / 60.0
        print(f"\n[{event.peak_severity}] {FAULT_TITLE.get(event.fault, event.fault)}")
        print(f"  When       : {when}  ({event.n_samples} samples, {mins:.1f} min)")
        print(f"  Channels   : {', '.join(SENSOR_LABEL.get(s, s) for s in event.affected_sensors) or 'station-wide'}")
        print(f"  Confidence : anomaly {event.max_anomaly_confidence:.2f} / "
              f"cause {event.max_root_cause_confidence:.2f}")
        print(f"  Diagnosis  : {event.representative.explanation.narrative}")
        rec = event.representative.recommendation
        print(f"  Data action: {rec.qc_action} - {rec.qc_note}")
        print(f"  Field action: {rec.field_actions[0] if rec.field_actions else 'none'}")
        print(f"  Notify     : {', '.join(rec.notify)}")

    if not actionable:
        print("\n  No high-severity incidents in this period.")

    if evaluation:
        det = evaluation["detection"]
        rc = evaluation["root_cause"]
        print(f"\n{line}\nVALIDATION AGAINST GROUND TRUTH\n{line}")
        print(f"Detection  : precision {det['precision']}  recall {det['recall']}  "
              f"F1 {det['f1']}  accuracy {det['accuracy']}")
        print(f"Root cause : {rc['correct']}/{rc['of_detected']} correctly attributed "
              f"({rc['accuracy']:.1%})")

        print("\nFault attribution matrix (rows = true, columns = diagnosed)")
        faults = [NO_FAULT, SPIKE, FROZEN_SENSOR, DRIFT, MULTIVARIATE_ANOMALY,
                  COMMUNICATION_FAILURE, UNKNOWN_ANOMALY]
        header = "".join(f"{f[:8]:>10}" for f in faults)
        label = "true \\ pred"
        print(f"  {label:<16}{header}")
        for true_type, row in sorted(evaluation["fault_matrix"].items()):
            cells = "".join(f"{row.get(f, 0):>10}" for f in faults)
            print(f"  {true_type:<16}{cells}")

        print("\nConfidence calibration (is the stated confidence honest?)")
        print(f"  {'stated':<14}{'n':>6}{'actually anomalous':>22}")
        for row in evaluation["confidence_calibration"]:
            print(f"  {row['confidence_range']:<14}{row['n_samples']:>6}"
                  f"{row['actually_anomalous_pct']:>21.1f}%")
    print()


# --------------------------------------------------------------------------
# Output writers
# --------------------------------------------------------------------------

def write_outputs(outdir: str, diagnoses: List[Diagnosis], events: List[FaultEvent],
                  summary: Dict[str, Any], evaluation: Optional[Dict[str, Any]]) -> List[str]:
    os.makedirs(outdir, exist_ok=True)
    written: List[str] = []

    report_path = os.path.join(outdir, "diagnosis_report.json")
    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "problem_statement": "PS 26073 - Intelligent Anomaly Detection for AWS",
        "module": "Member 4 - Diagnosis, Explainability, Confidence",
        "summary": summary,
        "events": [e.to_dict() for e in events],
        "evaluation": evaluation,
        "samples": [d.to_dict(full=False) for d in diagnoses],
    }
    with open(report_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, default=str)
    written.append(report_path)

    summary_path = os.path.join(outdir, "diagnosis_summary.csv")
    with open(summary_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "datetime", "temperature_c", "pressure_hpa", "humidity_pct",
            "fault", "affected_sensors", "anomaly_confidence", "root_cause_confidence",
            "severity", "severity_score", "priority", "qc_action",
            "top_feature", "top_feature_pct", "explanation",
        ])
        for d in diagnoses:
            top = d.explanation.top_feature
            writer.writerow([
                d.record.timestamp.isoformat() if d.record.timestamp else "",
                d.record.values.get("temperature_c", ""),
                d.record.values.get("pressure_hpa", ""),
                d.record.values.get("humidity_pct", ""),
                d.fault,
                "|".join(d.root_cause.primary.affected_sensors),
                round(d.assessment.anomaly_confidence, 3),
                round(d.assessment.root_cause_confidence, 3),
                d.assessment.severity,
                round(d.assessment.severity_score, 1),
                d.assessment.priority,
                d.recommendation.qc_action,
                top.feature if top else "",
                round(top.contribution_pct, 1) if top else "",
                d.explanation.narrative,
            ])
    written.append(summary_path)

    events_path = os.path.join(outdir, "events.csv")
    with open(events_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "start", "end", "duration_s", "n_samples", "fault", "affected_sensors",
            "severity", "severity_score", "anomaly_confidence", "root_cause_confidence",
            "qc_action", "urgency", "notify", "narrative",
        ])
        for e in events:
            rec = e.representative.recommendation
            writer.writerow([
                e.start.isoformat() if e.start else "",
                e.end.isoformat() if e.end else "",
                int(e.duration_seconds),
                e.n_samples,
                e.fault,
                "|".join(e.affected_sensors),
                e.peak_severity,
                round(e.peak_severity_score, 1),
                round(e.max_anomaly_confidence, 3),
                round(e.max_root_cause_confidence, 3),
                rec.qc_action,
                rec.urgency,
                "; ".join(rec.notify),
                e.representative.explanation.narrative,
            ])
    written.append(events_path)

    return written


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="SkyGuard diagnosis pipeline (PS 26073, Member 4)."
    )
    parser.add_argument("--train", required=True, help="Healthy training CSV (baseline).")
    parser.add_argument("--ml", help="Member 2 predictions CSV.")
    parser.add_argument("--temporal", help="Member 3 anomaly-signals CSV.")
    parser.add_argument("--outdir", default="diagnosis_output", help="Output directory.")
    parser.add_argument("--evaluate", action="store_true",
                        help="Score against ground-truth labels, if present.")
    parser.add_argument("--quiet", action="store_true", help="Suppress the console report.")
    args = parser.parse_args()

    print("SkyGuard diagnosis pipeline")
    print("  Learning healthy baseline...")
    train_rows = load_csv(args.train)
    baseline = Baseline.from_rows(train_rows)
    background = [{s: float(r[s]) for s in SENSORS} for r in train_rows[:600]]
    print(f"  Baseline: {baseline.n_rows} rows, "
          f"{baseline.sampling_interval_s:.0f}s nominal interval.")

    records = merge_sources(args.ml, args.temporal)

    print("  Diagnosing...")
    pipeline = DiagnosisPipeline(baseline, background=background)
    diagnoses = pipeline.run(records)

    events = group_events(diagnoses)
    summary = pipeline.summary(diagnoses, events)
    evaluation = pipeline.evaluate(diagnoses) if args.evaluate else None

    if not args.quiet:
        print_report(summary, events, evaluation)

    written = write_outputs(args.outdir, diagnoses, events, summary, evaluation)
    print("Written:")
    for path in written:
        print(f"  {path}")


if __name__ == "__main__":
    main()
