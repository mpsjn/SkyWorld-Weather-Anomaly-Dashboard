"""Member 3: simple temporal and multivariate anomaly checks.

Run:
python member3_temporal_multivariate_analysis.py train_raw.csv test_data.csv output.csv
"""

import csv
import sys
from statistics import mean, stdev


SENSORS = ["temperature_c", "pressure_hpa", "humidity_pct"]

# Easy-to-change rules for this prototype.
FROZEN_READINGS = 20
SPIKE_LIMITS = {"temperature_c": 2.0, "pressure_hpa": 2.0, "humidity_pct": 5.0}
DRIFT_LIMITS = {"temperature_c": 3.0, "pressure_hpa": 3.0, "humidity_pct": 8.0}
DRIFT_WINDOW = 12


def read_data(path):
    with open(path, newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))
    for row in rows:
        for sensor in SENSORS:
            row[sensor] = float(row[sensor])
    return rows


def get_normal_ranges(training_rows):
    """Find the normal average and normal spread for each sensor."""
    ranges = {}
    for sensor in SENSORS:
        values = [row[sensor] for row in training_rows]
        ranges[sensor] = {"average": mean(values), "spread": max(stdev(values), 0.01)}
    return ranges


def frozen_sensor_name(rows, current_index):
    """Return a sensor name only when its last 20 readings are identical."""
    if current_index < FROZEN_READINGS - 1:
        return ""
    window = rows[current_index - FROZEN_READINGS + 1:current_index + 1]
    for sensor in SENSORS:
        if len({row[sensor] for row in window}) == 1:
            return sensor
    return ""


def analyse(test_rows, normal_ranges):
    results = []

    for index, row in enumerate(test_rows):
        spike_sensors = []
        temporal_score = 0.0

        # Spike: compare the current reading with the immediately previous one.
        if index > 0:
            previous = test_rows[index - 1]
            for sensor in SENSORS:
                change = abs(row[sensor] - previous[sensor])
                score = change / SPIKE_LIMITS[sensor]
                temporal_score = max(temporal_score, score)
                if score >= 1:
                    spike_sensors.append(sensor)

        # Drift: compare the current reading with the reading 12 steps earlier.
        drift_sensors = []
        if index >= DRIFT_WINDOW and not spike_sensors:
            earlier = test_rows[index - DRIFT_WINDOW]
            for sensor in SENSORS:
                total_change = abs(row[sensor] - earlier[sensor])
                if total_change >= DRIFT_LIMITS[sensor]:
                    drift_sensors.append(sensor)

        frozen_name = frozen_sensor_name(test_rows, index)

        # Multivariate score: average how far each sensor is from its normal average.
        # A value 5 normal spreads away gets a score of 1.0.
        z_scores = []
        for sensor in SENSORS:
            average = normal_ranges[sensor]["average"]
            spread = normal_ranges[sensor]["spread"]
            z_scores.append(abs(row[sensor] - average) / spread)
        multivariate_score = min(1.0, mean(z_scores) / 5)

        reasons = []
        if spike_sensors:
            reasons.append("spike in " + ", ".join(spike_sensors))
        if drift_sensors:
            reasons.append("drift in " + ", ".join(drift_sensors))
        if frozen_name:
            reasons.append("possible frozen " + frozen_name + " sensor")
        if multivariate_score >= 0.8:
            reasons.append("unusual combined sensor values")

        result = dict(row)
        result.update({
            "temporal_score": round(min(temporal_score, 1.0), 3),
            "multivariate_score": round(multivariate_score, 3),
            "frozen_sensor": bool(frozen_name),
            "spike_detected": bool(spike_sensors),
            "drift_detected": bool(drift_sensors),
            "temporal_reason": "; ".join(reasons) or "normal recent behaviour",
        })
        results.append(result)

    return results


def save_data(rows, output_path):
    with open(output_path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def main():
    if len(sys.argv) != 4:
        raise SystemExit("Usage: python member3_temporal_multivariate_analysis.py train_raw.csv test_data.csv output.csv")

    training_rows = read_data(sys.argv[1])
    test_rows = read_data(sys.argv[2])
    normal_ranges = get_normal_ranges(training_rows)
    results = analyse(test_rows, normal_ranges)
    save_data(results, sys.argv[3])
    print("Created", sys.argv[3])


if __name__ == "__main__":
    main()
