"""SkyGuard AI dashboard. Run with: python -m streamlit run app.py"""
from pathlib import Path
import json
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="SkyGuard AI", page_icon="🌦️", layout="wide")
st.title("🌦️ SkyGuard AI")
st.caption("PS 26073 — Intelligent Anomaly Detection for Automatic Weather Stations")

report_path = ROOT / "diagnosis_report.json"
summary_path = ROOT / "diagnosis_summary.csv"
events_path = ROOT / "events.csv"
test_path = ROOT / "test_with_anomalies.csv"

if not report_path.exists() or not summary_path.exists():
    st.warning("No diagnosis output found yet. Run the integrated pipeline first:")
    st.code("python run_pipeline.py", language="bash")
    st.stop()

with report_path.open(encoding="utf-8") as f:
    report = json.load(f)
summary = pd.read_csv(summary_path)
events = pd.read_csv(events_path) if events_path.exists() else pd.DataFrame()

s = report.get("summary", {})
evaluation = report.get("evaluation") or {}

# Flexible extraction so the dashboard works with the current diagnosis schema.
def pick(*keys, default=0):
    for k in keys:
        if k in s and s[k] is not None:
            return s[k]
    return default

c1, c2, c3, c4 = st.columns(4)
c1.metric("Samples", len(summary))
c2.metric("Fault Samples", int(summary.get("fault", pd.Series(dtype=object)).astype(str).ne("NO_FAULT").sum()) if "fault" in summary else int(pick("fault_samples")))
c3.metric("Events", len(events))
c4.metric("Detection F1", f"{evaluation.get('f1', evaluation.get('f1_score', 0)):.3f}" if evaluation else "—")

st.divider()

left, right = st.columns([2, 1])
with left:
    st.subheader("Sensor readings")
    chart_cols = [c for c in ["temperature_c", "pressure_hpa", "humidity_pct"] if c in summary]
    if chart_cols:
        st.line_chart(summary.set_index("datetime")[chart_cols])

with right:
    st.subheader("Severity")
    if "severity" in summary:
        st.bar_chart(summary["severity"].value_counts())
    st.subheader("Fault types")
    if "fault" in summary:
        st.bar_chart(summary["fault"].value_counts())

st.divider()
st.subheader("Evaluation")
if evaluation:
    cols = st.columns(5)
    metrics = [
        ("Precision", evaluation.get("precision")),
        ("Recall", evaluation.get("recall")),
        ("F1", evaluation.get("f1", evaluation.get("f1_score"))),
        ("Accuracy", evaluation.get("accuracy")),
        ("Root-cause attribution", evaluation.get("root_cause_accuracy", evaluation.get("root_cause_correct_pct"))),
    ]
    for col, (name, value) in zip(cols, metrics):
        col.metric(name, "—" if value is None else (f"{value*100:.1f}%" if isinstance(value, (int,float)) and value <= 1 else f"{value:.1f}%"))

st.divider()
st.subheader("🚨 Detected incidents")
if events.empty:
    st.info("No events in the current output.")
else:
    show = [c for c in ["start","end","fault","affected_sensors","severity","anomaly_confidence","root_cause_confidence","urgency","qc_action"] if c in events.columns]
    st.dataframe(events[show], use_container_width=True, hide_index=True)

st.subheader("🔍 Sample-level diagnosis")
filter_fault = st.checkbox("Show faults only")
view = summary.copy()
if filter_fault and "fault" in view:
    view = view[view["fault"].astype(str) != "NO_FAULT"]
st.dataframe(view, use_container_width=True, hide_index=True)

st.caption("Raw observations are preserved; dashboard values are derived from the integrated diagnosis outputs.")
