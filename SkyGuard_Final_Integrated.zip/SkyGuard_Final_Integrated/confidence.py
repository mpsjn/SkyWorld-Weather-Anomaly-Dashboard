"""
SkyGuard / PS 26073 - AI-ML Based Intelligent Anomaly Detection for AWS
=======================================================================
Member 4 - Module 3 of 4 :  CONFIDENCE AND SEVERITY

Three separate questions that are easy to confuse, and must not be:

    1. ANOMALY CONFIDENCE    - how sure are we that ANYTHING is wrong?
    2. ROOT-CAUSE CONFIDENCE - given something is wrong, how sure are we
                               that we named the RIGHT fault?
    3. SEVERITY              - how much does it MATTER, and how fast must
                               somebody respond?

These are independent. A frozen humidity sensor can be a near-certain
detection (high anomaly confidence) whose exact cause is ambiguous (low
root-cause confidence) and whose operational impact is moderate. A single
spike can be certain, certainly a spike, and almost harmless.

Severity deliberately does NOT track confidence. A suspected total
communication failure at a cyclone-monitoring station is high severity even
at moderate confidence, because the cost of ignoring it is asymmetric.

Author : Member 4 (Diagnosis & Explainability)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from root_cause import (
    COMMUNICATION_FAILURE,
    DRIFT,
    FROZEN_SENSOR,
    MULTIVARIATE_ANOMALY,
    NO_FAULT,
    SENSOR_LABEL,
    SENSORS,
    SPIKE,
    UNKNOWN_ANOMALY,
    Baseline,
    RootCauseResult,
    SignalRecord,
)


# --------------------------------------------------------------------------
# Scales
# --------------------------------------------------------------------------

CONFIDENCE_BANDS = [
    (0.85, "Very high"),
    (0.70, "High"),
    (0.50, "Moderate"),
    (0.30, "Low"),
    (0.00, "Very low"),
]

SEVERITY_LEVELS = ["INFO", "LOW", "MODERATE", "HIGH", "CRITICAL"]

SEVERITY_BANDS = [
    (80.0, "CRITICAL"),
    (60.0, "HIGH"),
    (40.0, "MODERATE"),
    (20.0, "LOW"),
    (0.0, "INFO"),
]

# Response-time expectation attached to each severity level, so the dashboard
# shows an SLA rather than just a colour.
SEVERITY_SLA = {
    "CRITICAL": "Respond immediately; suspend publication of this station's data.",
    "HIGH": "Investigate within 24 hours; flag affected data as suspect.",
    "MODERATE": "Schedule inspection within the next maintenance cycle.",
    "LOW": "Log for trend analysis; no immediate field action.",
    "INFO": "No action required.",
}

# Baseline operational impact of each fault class, before modifiers.
# Drift scores higher than a spike despite being smaller, because a spike is
# obvious and easy to filter, while drift silently corrupts every downstream
# product (forecast initialisation, climatology) until it is caught.
BASE_SEVERITY: Dict[str, float] = {
    COMMUNICATION_FAILURE: 52.0,
    FROZEN_SENSOR: 44.0,
    DRIFT: 42.0,
    MULTIVARIATE_ANOMALY: 40.0,
    SPIKE: 22.0,
    UNKNOWN_ANOMALY: 26.0,
    NO_FAULT: 0.0,
}

# CRITICAL must stay rare or it stops meaning anything. With the modifiers
# below, only a persistent multi-channel fault or a large telemetry outage
# reaches it - roughly 2% of samples on the validation set, not 14%.

# Relative importance of each channel to IMD products at a surface station.
SENSOR_CRITICALITY: Dict[str, float] = {
    "pressure_hpa": 1.15,     # drives synoptic analysis and cyclone tracking
    "temperature_c": 1.05,
    "humidity_pct": 1.00,
}


def _band(value: float, bands) -> str:
    for threshold, label in bands:
        if value >= threshold:
            return label
    return bands[-1][1]


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


# --------------------------------------------------------------------------
# Results
# --------------------------------------------------------------------------

@dataclass
class ConfidenceAssessment:
    anomaly_confidence: float
    anomaly_band: str
    root_cause_confidence: float
    root_cause_band: str
    severity_score: float
    severity: str
    severity_sla: str
    priority: int                     # 1 = most urgent, for dashboard sorting
    components: Dict[str, Any] = field(default_factory=dict)
    reasoning: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "anomaly_confidence": round(self.anomaly_confidence, 3),
            "anomaly_confidence_band": self.anomaly_band,
            "root_cause_confidence": round(self.root_cause_confidence, 3),
            "root_cause_confidence_band": self.root_cause_band,
            "severity_score": round(self.severity_score, 1),
            "severity": self.severity,
            "severity_sla": self.severity_sla,
            "priority": self.priority,
            "components": self.components,
            "reasoning": self.reasoning,
        }


# --------------------------------------------------------------------------
# Scorer
# --------------------------------------------------------------------------

@dataclass
class ConfidenceConfig:
    # Weights for the three independent detectors in the anomaly vote.
    weight_ml: float = 0.34
    weight_temporal: float = 0.33
    weight_multivariate: float = 0.33

    agreement_bonus: float = 0.12     # applied when all three agree
    conflict_penalty: float = 0.10    # applied when rules and ML disagree

    persistence_window: int = 30      # look-back for a recurring fault
    max_persistence_boost: float = 10.0


class ConfidenceScorer:
    """Assigns anomaly confidence, root-cause confidence and severity."""

    def __init__(self, baseline: Baseline, config: Optional[ConfidenceConfig] = None):
        self.baseline = baseline
        self.cfg = config or ConfidenceConfig()

    # -- 1. anomaly confidence ---------------------------------------------

    def anomaly_confidence(self, result: RootCauseResult) -> Dict[str, Any]:
        """
        How sure are we that this sample is not healthy?

        Built from the three detectors voting independently. Independent
        agreement is genuine evidence; a single detector firing alone is not.
        """
        record = result.record
        cfg = self.cfg

        # Each detector contributes a 0..1 strength.
        ml_strength = _clamp(record.ml_anomaly_score / 100.0)
        temporal_strength = _clamp(record.temporal_score)
        multivariate_strength = _clamp(record.multivariate_score)

        # The rule engine's own belief is the strongest single signal, since
        # it is the only component that had to match a physical signature.
        rule_strength = _clamp(result.primary.score)

        ml_fired = record.ml_flag or ml_strength >= 0.5
        temporal_fired = record.spike_flag or record.drift_flag or record.frozen_flag
        multi_fired = multivariate_strength >= 0.8
        votes = sum([bool(ml_fired), bool(temporal_fired), bool(multi_fired)])

        weighted = (
            cfg.weight_ml * ml_strength
            + cfg.weight_temporal * temporal_strength
            + cfg.weight_multivariate * multivariate_strength
        )

        # The rule engine is given equal standing with the detector vote.
        confidence = 0.5 * rule_strength + 0.5 * weighted

        reasoning: List[str] = []
        if votes == 3:
            confidence += cfg.agreement_bonus
            reasoning.append("All three independent detectors agree.")
        elif votes == 2:
            confidence += cfg.agreement_bonus / 2
            reasoning.append("Two of three independent detectors agree.")
        elif votes == 1:
            reasoning.append("Only one detector fired; corroboration is weak.")
        elif votes == 0 and rule_strength > 0:
            confidence -= cfg.conflict_penalty
            reasoning.append(
                "No upstream detector fired; this rests on the rule engine alone."
            )

        # A strong rule match with a quiet ML model is a real conflict.
        if rule_strength >= 0.7 and ml_strength < 0.3:
            confidence -= cfg.conflict_penalty
            reasoning.append(
                "The rule engine is confident but the ML model scored this sample as normal."
            )

        # Missing data means we are reasoning with less than a full frame.
        if record.missing_sensors:
            confidence -= 0.05 * len(record.missing_sensors)
            reasoning.append("Confidence reduced: the sample frame is incomplete.")

        confidence = _clamp(confidence)

        return {
            "value": confidence,
            "votes": votes,
            "reasoning": reasoning,
            "components": {
                "ml_strength": round(ml_strength, 3),
                "temporal_strength": round(temporal_strength, 3),
                "multivariate_strength": round(multivariate_strength, 3),
                "rule_strength": round(rule_strength, 3),
                "detector_votes": votes,
            },
        }

    # -- 2. root-cause confidence ------------------------------------------

    def root_cause_confidence(self, result: RootCauseResult) -> Dict[str, Any]:
        """
        Given that something is wrong, how sure are we WHICH fault it is?

        Driven by three things: how strongly the winning hypothesis fired, how
        far clear of the runner-up it is, and how much independent evidence
        supports it. A narrow win over a competing hypothesis is reported as
        genuinely uncertain rather than smoothed over.
        """
        primary = result.primary
        reasoning: List[str] = []

        if primary.fault == NO_FAULT:
            return {
                "value": 0.0,
                "reasoning": ["No fault was diagnosed."],
                "components": {},
            }

        strength = _clamp(primary.score)

        # Separation from the next hypothesis, normalised.
        runner_score = result.runner_up.score if result.runner_up else 0.0
        margin = _clamp((primary.score - runner_score) / max(primary.score, 1e-6))

        # Evidence diversity: several DIFFERENT checks firing is much stronger
        # than one check firing hard.
        distinct_checks = len({e.check for e in primary.evidence})
        diversity = _clamp(distinct_checks / 3.0)

        confidence = 0.45 * strength + 0.35 * margin + 0.20 * diversity

        if runner_score > 0 and margin < 0.25:
            reasoning.append(
                f"Close call against {primary.fault.replace('_', ' ').lower()} vs "
                f"{result.runner_up.fault.replace('_', ' ').lower()}; "
                "treat the named cause as provisional."
            )
        if distinct_checks >= 3:
            reasoning.append(f"{distinct_checks} independent checks support this cause.")
        elif distinct_checks == 1:
            reasoning.append("Only one check supports this cause.")

        # Known physical detectability limits lower our confidence honestly.
        if primary.fault == FROZEN_SENSOR:
            for sensor in primary.affected_sensors:
                sb = self.baseline.sensors[sensor]
                if sb.longest_natural_run > 40:
                    confidence *= 0.8
                    reasoning.append(
                        f"{SENSOR_LABEL[sensor]} naturally holds a constant value for long "
                        "periods, so a stuck reading is intrinsically ambiguous here."
                    )
                    break

        if primary.fault == UNKNOWN_ANOMALY:
            confidence = min(confidence, 0.25)
            reasoning.append("No fault signature matched; the cause is unclassified.")

        if primary.details.get("explained_away_by"):
            reasoning.append("A competing hypothesis was demoted as a side effect of this one.")

        confidence = _clamp(confidence)
        return {
            "value": confidence,
            "reasoning": reasoning,
            "components": {
                "hypothesis_strength": round(strength, 3),
                "margin_over_runner_up": round(margin, 3),
                "evidence_diversity": round(diversity, 3),
                "distinct_checks": distinct_checks,
                "runner_up": result.runner_up.fault if result.runner_up else None,
            },
        }

    # -- 3. severity --------------------------------------------------------

    def severity(
        self,
        result: RootCauseResult,
        history: Optional[List[RootCauseResult]] = None,
    ) -> Dict[str, Any]:
        """
        Operational impact, NOT probability.

        Deliberately independent of confidence: a suspected communication
        failure at a station feeding cyclone warnings stays high severity even
        when confidence is moderate, because the cost of missing it is
        asymmetric. Confidence and severity are shown side by side so an
        operator can tell "probably harmless" from "possibly disastrous".
        """
        primary = result.primary
        reasoning: List[str] = []

        if primary.fault == NO_FAULT:
            return {
                "score": 0.0,
                "level": "INFO",
                "sla": SEVERITY_SLA["INFO"],
                "reasoning": ["No fault detected."],
                "components": {},
            }

        score = BASE_SEVERITY.get(primary.fault, 30.0)
        components: Dict[str, Any] = {"base": score}

        # (a) Which channel is affected.
        criticality = max(
            (SENSOR_CRITICALITY.get(s, 1.0) for s in primary.affected_sensors),
            default=1.0,
        )
        score *= criticality
        components["channel_criticality"] = round(criticality, 2)
        if criticality > 1.1:
            reasoning.append(
                "Affects barometric pressure, which feeds synoptic analysis and "
                "cyclone tracking."
            )

        # (b) How many channels are involved.
        n_affected = len(primary.affected_sensors)
        if n_affected >= 2:
            multiplier = 1.0 + 0.12 * (n_affected - 1)
            score *= multiplier
            components["multi_channel_multiplier"] = round(multiplier, 2)
            reasoning.append(f"{n_affected} channels affected simultaneously.")

        # (c) Magnitude of the deviation.
        magnitude = self._magnitude_factor(result)
        score *= magnitude
        components["magnitude_factor"] = round(magnitude, 2)

        # (d) Persistence: a fault that keeps recurring is worse than a
        #     one-off, because it will not self-clear.
        if history:
            window = history[-self.cfg.persistence_window:]
            repeats = sum(1 for h in window if h.primary.fault == primary.fault)
            if repeats >= 3:
                boost = min(self.cfg.max_persistence_boost, 2.0 * repeats)
                score += boost
                components["persistence_boost"] = round(boost, 1)
                reasoning.append(
                    f"Same fault seen {repeats} times in the last "
                    f"{len(window)} samples - persistent, not transient."
                )

        # (e) Data usability: a fault that silently corrupts data is worse
        #     than one that is obvious downstream.
        if primary.fault in (DRIFT, FROZEN_SENSOR, MULTIVARIATE_ANOMALY):
            score += 4.0
            components["silent_corruption_penalty"] = 4.0
            reasoning.append(
                "Readings remain plausible, so bad data can pass quality control unnoticed."
            )

        score = max(0.0, min(100.0, score))
        level = _band(score, SEVERITY_BANDS)

        return {
            "score": score,
            "level": level,
            "sla": SEVERITY_SLA[level],
            "reasoning": reasoning,
            "components": components,
        }

    def _magnitude_factor(self, result: RootCauseResult) -> float:
        """Scale severity by how extreme the deviation actually is."""
        primary = result.primary
        record = result.record

        if primary.fault == SPIKE:
            sigmas = primary.details.get("max_step_sigmas", 0.0)
            return _clamp(0.7 + sigmas / 50.0, 0.7, 1.35)

        if primary.fault == DRIFT:
            worst = 0.0
            for sensor in primary.affected_sensors:
                worst = max(worst, abs(primary.details.get(f"{sensor}_offset_sigmas", 0.0)))
            return _clamp(0.8 + worst / 25.0, 0.8, 1.35)

        if primary.fault == FROZEN_SENSOR:
            longest = max(
                (primary.details.get(f"{s}_run", 0) for s in primary.affected_sensors),
                default=0,
            )
            minutes = longest * self.baseline.sampling_interval_s / 60.0
            return _clamp(0.8 + minutes / 150.0, 0.8, 1.35)

        if primary.fault == COMMUNICATION_FAILURE:
            lost = primary.details.get("estimated_lost_samples", 0)
            return _clamp(0.9 + lost / 40.0, 0.9, 1.5)

        if primary.fault == MULTIVARIATE_ANOMALY:
            distance = primary.details.get("mahalanobis", 0.0)
            threshold = max(primary.details.get("mahalanobis_threshold", 1.0), 1e-6)
            return _clamp(0.8 + (distance / threshold) / 12.0, 0.8, 1.35)

        return 1.0

    # -- combined -----------------------------------------------------------

    def assess(
        self,
        result: RootCauseResult,
        history: Optional[List[RootCauseResult]] = None,
    ) -> ConfidenceAssessment:
        anomaly = self.anomaly_confidence(result)
        cause = self.root_cause_confidence(result)
        sev = self.severity(result, history)

        reasoning = anomaly["reasoning"] + cause["reasoning"] + sev["reasoning"]

        # Dashboard sort key: severity first, then how sure we are.
        severity_rank = SEVERITY_LEVELS.index(sev["level"])
        priority = max(1, 5 - severity_rank)
        if anomaly["value"] < 0.4 and priority < 5:
            priority += 1  # push low-confidence items down the queue

        return ConfidenceAssessment(
            anomaly_confidence=anomaly["value"],
            anomaly_band=_band(anomaly["value"], CONFIDENCE_BANDS),
            root_cause_confidence=cause["value"],
            root_cause_band=_band(cause["value"], CONFIDENCE_BANDS),
            severity_score=sev["score"],
            severity=sev["level"],
            severity_sla=sev["sla"],
            priority=priority,
            components={
                "anomaly": anomaly["components"],
                "root_cause": cause["components"],
                "severity": sev["components"],
            },
            reasoning=reasoning,
        )


# --------------------------------------------------------------------------
# Calibration check
# --------------------------------------------------------------------------

def calibration_report(
    assessments: List[ConfidenceAssessment],
    truths: List[Optional[bool]],
    bins: int = 5,
) -> List[Dict[str, Any]]:
    """
    Is the stated confidence honest?

    Groups samples by stated anomaly confidence and reports how many were
    genuinely anomalous. A well-calibrated system that says "0.8 confident"
    should be right about 80% of the time. Publishing this stops confidence
    from being a decorative number.
    """
    buckets: List[Dict[str, Any]] = []
    for b in range(bins):
        low, high = b / bins, (b + 1) / bins
        selected = [
            truth
            for assessment, truth in zip(assessments, truths)
            if truth is not None and low <= assessment.anomaly_confidence < high + (1e-9 if b == bins - 1 else 0)
        ]
        if not selected:
            continue
        buckets.append({
            "confidence_range": f"{low:.1f}-{high:.1f}",
            "n_samples": len(selected),
            "actually_anomalous_pct": round(100.0 * sum(1 for t in selected if t) / len(selected), 1),
        })
    return buckets


# --------------------------------------------------------------------------
# Self-test
# --------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    from root_cause import RootCauseAnalyzer, load_baseline, records_from_csv

    if len(sys.argv) != 3:
        print("Usage: python confidence.py <train_raw.csv> <signals.csv>")
        raise SystemExit(1)

    baseline = load_baseline(sys.argv[1])
    records = records_from_csv(sys.argv[2])
    analyzer = RootCauseAnalyzer(baseline)
    results = analyzer.analyze_stream(records)

    scorer = ConfidenceScorer(baseline)
    assessments = []
    for i, result in enumerate(results):
        assessments.append(scorer.assess(result, results[:i]))

    from collections import Counter
    sev_counts = Counter(a.severity for a in assessments if a.severity != "INFO")

    print("Severity distribution (faults only)")
    for level in reversed(SEVERITY_LEVELS):
        if sev_counts.get(level):
            print(f"  {level:<10} {sev_counts[level]:>4}")

    faulty = [(r, a) for r, a in zip(results, assessments) if r.is_fault]
    if faulty:
        avg_anom = sum(a.anomaly_confidence for _, a in faulty) / len(faulty)
        avg_cause = sum(a.root_cause_confidence for _, a in faulty) / len(faulty)
        print(f"\nMean anomaly confidence   : {avg_anom:.3f}")
        print(f"Mean root-cause confidence: {avg_cause:.3f}")

    truths = [r.record.truly_anomalous for r in results]
    print("\nCalibration of stated anomaly confidence")
    print(f"  {'confidence':<14}{'n':>6}{'actually anomalous':>22}")
    for row in calibration_report(assessments, truths):
        print(f"  {row['confidence_range']:<14}{row['n_samples']:>6}"
              f"{row['actually_anomalous_pct']:>21.1f}%")
