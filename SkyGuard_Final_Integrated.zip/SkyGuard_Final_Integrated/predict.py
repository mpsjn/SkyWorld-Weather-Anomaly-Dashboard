import json
import joblib
import numpy as np
import pandas as pd

MODEL_PATH = "anomaly_model.pkl"
METADATA_PATH = "metadata.json"

model = joblib.load(MODEL_PATH)
with open(METADATA_PATH, "r") as f:
    metadata = json.load(f)

FEATURES = metadata["features"]
THRESHOLD = metadata["decision_threshold"]

# Reconstruct a reference score range from the model's learned training
# distribution is not directly available in sklearn, so the 0-100 score
# below is based on a conservative transformation of decision_function.
# The classification itself uses the saved threshold.
def detect_anomaly(temperature_c, pressure_hpa, humidity_pct):
    row = pd.DataFrame([{
        "temperature_c": temperature_c,
        "pressure_hpa": pressure_hpa,
        "humidity_pct": humidity_pct
    }])

    decision = float(model.decision_function(row)[0])
    anomaly = decision < THRESHOLD

    # Relative score: lower decision values -> higher anomaly score.
    # This is intentionally described as a relative score, not probability.
    anomaly_score = float(np.clip(50 - 250 * decision, 0, 100))

    return {
        "anomaly": bool(anomaly),
        "anomaly_score": round(anomaly_score, 2),
        "decision_score": round(decision, 6)
    }


if __name__ == "__main__":
    # Example test
    result = detect_anomaly(55.0, 1006.5, 65.0)
    print(result)
