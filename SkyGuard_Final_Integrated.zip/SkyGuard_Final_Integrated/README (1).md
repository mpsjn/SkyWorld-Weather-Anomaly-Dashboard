# SkyGuard — Member 2: ML Anomaly Detection

## Responsibility
This module is the main ML anomaly detector for temperature, pressure and humidity sensor data.

## Algorithm
Isolation Forest (unsupervised anomaly detection).

## Input columns
- datetime
- temperature_c
- pressure_hpa
- humidity_pct

The model itself uses:
- temperature_c
- pressure_hpa
- humidity_pct

## Files
- `train_model.py` — trains and saves the model
- `predict.py` — reusable prediction function for the team
- `models/anomaly_model.pkl` — trained model
- `models/metadata.json` — model configuration and threshold
- `results/test_predictions.csv` — predictions on supplied test data
- `results/metrics.json` — evaluation metrics
- `results/classification_report.txt` — detailed evaluation
- `results/decision_scores.png` — score plot
- `results/confusion_matrix.png` — confusion matrix

## How to run

1. Put `train_raw.csv` in this folder.
2. Install:
   `pip install -r requirements.txt`
3. Train:
   `python train_model.py`
4. Test:
   `python predict.py`

## Team interface

Other members can use:

```python
from predict import detect_anomaly

result = detect_anomaly(
    temperature_c=55.0,
    pressure_hpa=1006.5,
    humidity_pct=65.0
)

print(result)
```

Example output:

```text
{
  "anomaly": true,
  "anomaly_score": ...,
  "decision_score": ...
}
```

### Important
`anomaly_score` is a relative 0–100 severity-style score, not a probability.
The root-cause module should combine this ML output with temporal/frozen/drift analysis from Member 3.

## Current evaluation on the supplied test file
The test file contains labelled examples of:
- normal
- spike
- frozen
- drift
- noise_burst
- cross_variable

The model was NOT trained on the test labels.
