"""SkyGuard integrated one-command pipeline (PS 26073).
All inputs and generated outputs stay in this single project folder.
"""
import subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PY = sys.executable

def run(*args):
    cmd = [PY, *args]
    print("\n>>>", " ".join(str(x) for x in cmd))
    subprocess.run(cmd, cwd=ROOT, check=True)

def main():
    run("train_model.py")
    run("predict_integrated.py", "--input", "test_with_anomalies.csv", "--output", "test_predictions_integrated.csv")
    run("member3_temporal_multivariate_analysis.py", "train_raw.csv", "test_with_anomalies.csv", "member3_anomaly_signals_integrated.csv")
    run("diagnosis.py", "--train", "train_raw.csv", "--ml", "test_predictions_integrated.csv", "--temporal", "member3_anomaly_signals_integrated.csv", "--outdir", ".", "--evaluate")
    print("\nSkyGuard integration completed successfully.")
    print("Dashboard: python -m streamlit run app.py")

if __name__ == "__main__":
    main()
