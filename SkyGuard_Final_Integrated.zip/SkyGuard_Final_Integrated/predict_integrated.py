"""Batch adapter for the integrated SkyGuard project."""
import argparse
import pandas as pd
from predict import detect_anomaly


def main():
    parser = argparse.ArgumentParser(description="Run SkyGuard ML prediction on a CSV")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    required = ["temperature_c", "pressure_hpa", "humidity_pct"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise SystemExit(f"Missing required columns: {missing}")

    results = [detect_anomaly(r.temperature_c, r.pressure_hpa, r.humidity_pct)
               for r in df.itertuples(index=False)]
    out = df.copy()
    out["anomaly_score"] = [r["anomaly_score"] for r in results]
    out["decision_score"] = [r["decision_score"] for r in results]
    out["predicted_anomaly"] = [int(r["anomaly"]) for r in results]
    out.to_csv(args.output, index=False)
    print(f"Created {args.output} ({len(out)} rows)")

if __name__ == "__main__":
    main()
