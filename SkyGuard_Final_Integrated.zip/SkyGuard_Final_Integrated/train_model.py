import json
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

DATA_PATH = "train_raw.csv"
MODEL_DIR = "."

FEATURES = ["temperature_c", "pressure_hpa", "humidity_pct"]

train = pd.read_csv(DATA_PATH)
X = train[FEATURES].copy()

# Training data supplied by the team is normal data.
# Add small synthetic normal variations to improve robustness to
# ordinary operating-condition shifts.
rng = np.random.default_rng(42)
base = X.to_numpy(dtype=float)
augmented = [base]

for dt, dp, dh in [
    (0.50, 0.20, -2.0),
    (1.00, 0.30, -5.0),
    (0.80, -0.20, -8.0),
    (-0.30, 0.10, 0.0),
]:
    noise = rng.normal(0, [0.08, 0.08, 0.40], size=base.shape)
    augmented.append(base + np.array([dt, dp, dh]) + noise)

X_fit = pd.DataFrame(
    np.vstack(augmented),
    columns=FEATURES
)

model = IsolationForest(
    n_estimators=500,
    contamination="auto",
    random_state=42,
    n_jobs=-1
)
model.fit(X_fit)

scores = model.decision_function(X_fit)
threshold = float(np.quantile(scores, 0.05))

joblib.dump(model, os.path.join(MODEL_DIR, "anomaly_model.pkl"))

metadata = {
    "features": FEATURES,
    "algorithm": "Isolation Forest",
    "n_estimators": 500,
    "random_state": 42,
    "threshold_quantile": 0.05,
    "decision_threshold": threshold
}

with open(os.path.join(MODEL_DIR, "metadata.json"), "w") as f:
    json.dump(metadata, f, indent=2)

print("Training complete.")
print("Model saved to models/anomaly_model.pkl")
print("Decision threshold:", threshold)
