"""
SkyGuard / PS 26073 - AI-ML Based Intelligent Anomaly Detection for AWS
=======================================================================
Member 4 - Module 1 of 4 :  ROOT CAUSE ANALYSIS

Purpose
-------
Members 2 and 3 answer "IS this reading anomalous?".
This module answers "WHAT is actually wrong with the station?".

It converts raw anomaly signals (Isolation Forest score + temporal flags +
multivariate score) into one of five physically meaningful AWS fault classes:

    1. SPIKE                  - sudden impulse / noise burst on a channel
    2. FROZEN_SENSOR          - channel stuck at a constant value
    3. DRIFT                  - slow calibration drift away from baseline
    4. COMMUNICATION_FAILURE  - missing packets, gaps, sentinel/blank values
    5. MULTIVARIATE_ANOMALY   - each sensor is individually fine, but the
                                COMBINATION is physically implausible

    (+ UNKNOWN_ANOMALY  - ML fired but no rule matched: reported honestly
       instead of being forced into a wrong class)
    (+ NO_FAULT         - healthy sample)

Design notes for the jury
-------------------------
* Every fault produces STRUCTURED EVIDENCE (check name, observed value,
  threshold, weight, strength). Nothing is a black box - explainability.py
  and confidence.py consume this evidence directly.
* Thresholds are learned from the training baseline (robust MAD statistics),
  not hard-coded magic numbers, so the same code works for any AWS station.
* Frozen detection is calibrated against the LONGEST NATURALLY CONSTANT RUN
  seen in training. A humidity sensor that is legitimately flat at night is
  not reported as frozen - this removes the main false-positive source.
* Pure standard library. numpy is used only if present.

Author : Member 4 (Diagnosis & Explainability)
"""

from __future__ import annotations

import csv
import math
import statistics
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence

# --------------------------------------------------------------------------
# Station configuration
# --------------------------------------------------------------------------

SENSORS: List[str] = ["temperature_c", "pressure_hpa", "humidity_pct"]

SENSOR_LABEL: Dict[str, str] = {
    "temperature_c": "Temperature",
    "pressure_hpa": "Barometric pressure",
    "humidity_pct": "Relative humidity",
}

SENSOR_UNIT: Dict[str, str] = {
    "temperature_c": "degC",
    "pressure_hpa": "hPa",
    "humidity_pct": "%RH",
}

# WMO / IMD plausible operating envelope for a surface AWS.
PHYSICAL_LIMITS: Dict[str, tuple] = {
    "temperature_c": (-40.0, 60.0),
    "pressure_hpa": (850.0, 1100.0),
    "humidity_pct": (0.0, 100.0),
}

# Values a dead datalogger typically transmits instead of a real reading.
SENTINEL_VALUES = (-999.0, -9999.0, 999.9, 9999.0)

# Fault class identifiers
SPIKE = "SPIKE"
FROZEN_SENSOR = "FROZEN_SENSOR"
DRIFT = "DRIFT"
COMMUNICATION_FAILURE = "COMMUNICATION_FAILURE"
MULTIVARIATE_ANOMALY = "MULTIVARIATE_ANOMALY"
UNKNOWN_ANOMALY = "UNKNOWN_ANOMALY"
NO_FAULT = "NO_FAULT"

FAULT_CLASSES = [
    SPIKE,
    FROZEN_SENSOR,
    DRIFT,
    COMMUNICATION_FAILURE,
    MULTIVARIATE_ANOMALY,
]

FAULT_TITLE: Dict[str, str] = {
    SPIKE: "Sensor spike / noise burst",
    FROZEN_SENSOR: "Frozen (stuck) sensor",
    DRIFT: "Calibration drift",
    COMMUNICATION_FAILURE: "Communication / telemetry failure",
    MULTIVARIATE_ANOMALY: "Cross-variable inconsistency",
    UNKNOWN_ANOMALY: "Unclassified statistical anomaly",
    NO_FAULT: "No fault detected",
}

# Maps the synthetic ground-truth labels used by Member 1's data generator
# onto our fault classes, so diagnosis.py can score itself.
GROUND_TRUTH_MAP: Dict[str, str] = {
    "normal": NO_FAULT,
    "spike": SPIKE,
    "noise_burst": SPIKE,
    "frozen": FROZEN_SENSOR,
    "drift": DRIFT,
    "cross_variable": MULTIVARIATE_ANOMALY,
    "comm_failure": COMMUNICATION_FAILURE,
    "missing": COMMUNICATION_FAILURE,
}


# --------------------------------------------------------------------------
# Tunable detector configuration
# --------------------------------------------------------------------------

@dataclass
class RCAConfig:
    """All tunables in one place so the team can tune without touching logic."""

    # --- Spike ---
    spike_sigma: float = 4.0          # step size in robust sigmas to call a spike
    spike_recovery_sigma: float = 4.0  # tolerance for "came back to where it was"
    burst_window: int = 10            # look-back for repeated spikes
    volatility_window: int = 8        # window for the local-roughness test
    volatility_ratio: float = 2.5     # roughness multiple (subtype labelling only)
    burst_min_spikes: int = 3         # >= this many spikes in window => noise burst

    # --- Frozen ---
    frozen_min_run: int = 12          # absolute floor for a stuck-value run
    frozen_natural_margin: float = 1.5  # run must exceed 1.5x longest natural run
    frozen_tolerance: float = 1e-9    # equality tolerance between readings

    # --- Drift ---
    drift_window: int = 20            # samples used to fit the trend. Must be
                                      # SHORTER than a typical drift event, or the
                                      # window mean is diluted with healthy data.
    drift_sigma: float = 3.5          # window-mean offset from baseline, in sigmas
    drift_monotonic_ratio: float = 0.5  # |net change| / total travel; separates
                                         # a real ramp from random walk noise
    drift_min_net_sigma: float = 1.5  # the window must actually MOVE, so that a
                                      # steady diurnal offset is not called drift

    # --- Communication ---
    comm_gap_factor: float = 1.8      # gap > 1.8x nominal interval => lost packets

    # --- Multivariate ---
    mahalanobis_sigma: float = 3.5    # FLOOR for the distance threshold; the
                                      # real bar is calibrated from training
    cross_var_univariate_max: float = 3.0  # "each sensor fine on its own" bound
    maha_stream_k: float = 6.0        # median + k*MAD bar re-fitted on the stream

    # --- Ranking ---
    min_fault_score: float = 0.30     # below this, a candidate is not reported
    explain_away_factor: float = 0.35  # demotion applied to a symptom hypothesis
    cross_var_dominance: float = 1.5  # x threshold before cross-variable outranks
    ml_anomaly_score_threshold: float = 50.0  # Member 2 score scale is 0..100
    # Raising an alarm on the ML binary flag alone is not viable: on the
    # validation set that flag has ~54% precision, which would bury the
    # operator in unexplained alerts. An ML-only alarm therefore needs a high
    # score AND corroboration from another module.
    ml_unknown_threshold: float = 85.0
    ml_unknown_solo_threshold: float = 95.0

    # MEASURED ON THE VALIDATION SET: ML detections that match no physical rule
    # were correct only 30.5% of the time - BELOW the 47% base rate - because
    # the upstream Isolation Forest has ROC-AUC 0.644. Enabling them added 57
    # false alarms to gain 25 true ones. They are therefore off by default.
    # Re-enable once the upstream model reaches roughly AUC > 0.8.
    enable_ml_only_alarms: bool = False


# --------------------------------------------------------------------------
# Baseline learned from healthy training data
# --------------------------------------------------------------------------

def _median(values: Sequence[float]) -> float:
    return statistics.median(values) if values else 0.0


def _mad(values: Sequence[float], center: Optional[float] = None) -> float:
    """Median absolute deviation, rescaled to be comparable to a std-dev."""
    if not values:
        return 0.0
    c = center if center is not None else _median(values)
    return 1.4826 * _median([abs(v - c) for v in values])


def _rolling_mean_spread(values: Sequence[float], window: int) -> float:
    """
    How much does a `window`-sample average naturally move on healthy data?

    Drift must be judged against THIS, not against the spread of individual
    readings - averaging 60 samples suppresses noise, so a window mean that
    has moved even slightly is already significant.
    """
    if len(values) <= window:
        return max(_mad(values), 1e-3)
    means = []
    running = sum(values[:window])
    means.append(running / window)
    for i in range(window, len(values)):
        running += values[i] - values[i - window]
        means.append(running / window)
    return max(_mad(means), statistics.pstdev(means) if len(means) > 1 else 0.0, 1e-3)


def _run_lengths(values: Sequence[float], tol: float) -> List[int]:
    """Lengths of every constant-value run in healthy data."""
    if not values:
        return []
    out: List[int] = []
    run = 1
    for i in range(1, len(values)):
        if abs(values[i] - values[i - 1]) <= tol:
            run += 1
        else:
            out.append(run)
            run = 1
    out.append(run)
    return out


def _longest_constant_run(values: Sequence[float], tol: float) -> int:
    best, run = 1, 1
    for i in range(1, len(values)):
        if abs(values[i] - values[i - 1]) <= tol:
            run += 1
            best = max(best, run)
        else:
            run = 1
    return best if values else 0


def _quantile(values: Sequence[float], p: float) -> float:
    """Simple order-statistic quantile (no numpy dependency)."""
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round(p * (len(ordered) - 1)))))
    return ordered[idx]


def _volatility_scale(values: Sequence[float], window: int) -> float:
    """
    Highest local roughness healthy data ever shows.

    A noise burst raises the AMPLITUDE of the jitter without producing one
    huge step, so it slips past a step-size test. Measuring mean |diff| over a
    short sliding window catches it.
    """
    diffs = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
    if len(diffs) < window:
        return max(_quantile(diffs, 0.99), 1e-3)
    roughness = []
    running = sum(diffs[:window])
    roughness.append(running / window)
    for i in range(window, len(diffs)):
        running += diffs[i] - diffs[i - window]
        roughness.append(running / window)
    return max(_quantile(roughness, 0.99), 1e-3)


def _resolution(values: Sequence[float]) -> float:
    """Smallest non-zero change a channel ever reports = its quantisation step."""
    diffs = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
    non_zero = [d for d in diffs if d > 1e-9]
    return min(non_zero) if non_zero else 0.1


@dataclass
class SensorBaseline:
    mean: float
    std: float
    median: float
    mad: float
    vmin: float
    vmax: float
    resolution: float          # quantisation step of the ADC (e.g. 0.1 degC)
    step_scale: float          # normal one-sample movement (99.5th pct of |diff|)
    volatility_scale: float    # normal local roughness (99th pct of window mean |diff|)
    window_mean_sigma: float   # how far a rolling mean naturally wanders
    longest_natural_run: int   # longest stuck-looking run in healthy data
    run_lengths: List[int] = field(default_factory=list)  # healthy run-length distribution

    def run_bar(self, floor: int) -> float:
        """Run length that healthy data exceeds only ~1% of the time."""
        if not self.run_lengths:
            return float(floor)
        return max(float(floor), float(_quantile([float(r) for r in self.run_lengths], 0.99)))

    def run_surprise(self, run: int) -> float:
        """
        P(healthy run < observed run) - a calibrated 0..1 strength instead of a
        binary verdict, because stuck-value runs and genuinely calm periods
        overlap heavily on a quantised channel.
        """
        if not self.run_lengths:
            return 0.0
        shorter = sum(1 for r in self.run_lengths if r < run)
        return shorter / len(self.run_lengths)

    @property
    def sigma(self) -> float:
        """Robust spread of the level, guarded against a degenerate zero."""
        return max(self.mad, self.std, self.resolution, 1e-3)

    @property
    def step_sigma(self) -> float:
        """
        Scale for one-sample movement.

        NOTE: a MAD of the differences is useless on a quantised sensor - 85%
        of consecutive readings here are byte-identical, so the MAD collapses
        to zero and every 0.1 degC tick looks like a 100-sigma spike. We use a
        high quantile of the observed movement with a resolution floor instead.
        """
        return max(self.step_scale, 2 * self.resolution, 1e-3)


@dataclass
class Baseline:
    """Healthy-behaviour fingerprint of the station, learned from train_raw.csv."""

    sensors: Dict[str, SensorBaseline]
    cov_inv: List[List[float]]
    means: List[float]
    sampling_interval_s: float
    n_rows: int
    mahalanobis_threshold: float = 3.5   # overwritten by from_rows() calibration

    # ---------------- construction ----------------

    @classmethod
    def from_rows(cls, rows: List[Dict[str, Any]], config: Optional[RCAConfig] = None) -> "Baseline":
        cfg = config or RCAConfig()
        if len(rows) < 10:
            raise ValueError("Baseline needs at least 10 training rows.")

        per_sensor: Dict[str, SensorBaseline] = {}
        columns: Dict[str, List[float]] = {}

        for sensor in SENSORS:
            values = [float(r[sensor]) for r in rows if r.get(sensor) not in (None, "")]
            columns[sensor] = values
            diffs = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
            med = _median(values)
            per_sensor[sensor] = SensorBaseline(
                mean=statistics.fmean(values),
                std=statistics.pstdev(values),
                median=med,
                mad=_mad(values, med),
                vmin=min(values),
                vmax=max(values),
                resolution=_resolution(values),
                step_scale=_quantile(diffs, 0.995),
                volatility_scale=_volatility_scale(values, cfg.volatility_window),
                window_mean_sigma=_rolling_mean_spread(values, cfg.drift_window),
                longest_natural_run=_longest_constant_run(values, cfg.frozen_tolerance),
                run_lengths=_run_lengths(values, cfg.frozen_tolerance),
            )

        means = [per_sensor[s].mean for s in SENSORS]
        cov_inv = _invert_3x3(_covariance(columns, means))
        interval = cls._nominal_interval(rows)

        baseline = cls(
            sensors=per_sensor,
            cov_inv=cov_inv,
            means=means,
            sampling_interval_s=interval,
            n_rows=len(rows),
        )

        # Calibrate the multivariate threshold on healthy data itself: whatever
        # joint distance the station never exceeds when healthy becomes the bar.
        n = min(len(columns[s]) for s in SENSORS)
        distances = [
            baseline.mahalanobis({s: columns[s][k] for s in SENSORS})
            for k in range(n)
        ]
        baseline.mahalanobis_threshold = max(
            cfg.mahalanobis_sigma, _quantile(distances, 0.995)
        )
        return baseline

    @staticmethod
    def _nominal_interval(rows: List[Dict[str, Any]]) -> float:
        stamps = []
        for r in rows:
            ts = parse_timestamp(r.get("datetime"))
            if ts:
                stamps.append(ts)
        deltas = [
            (stamps[i] - stamps[i - 1]).total_seconds()
            for i in range(1, len(stamps))
        ]
        positive = [d for d in deltas if d > 0]
        return _median(positive) if positive else 60.0

    # ---------------- use ----------------

    def z_score(self, sensor: str, value: float) -> float:
        sb = self.sensors[sensor]
        return (value - sb.median) / sb.sigma

    def mahalanobis(self, values: Dict[str, float]) -> float:
        """Distance of the joint reading from the healthy cloud, in sigmas."""
        d = [values[s] - self.means[i] for i, s in enumerate(SENSORS)]
        total = 0.0
        for i in range(3):
            for j in range(3):
                total += d[i] * self.cov_inv[i][j] * d[j]
        return math.sqrt(max(total, 0.0))

    def sample_values(self) -> Dict[str, float]:
        return {s: self.sensors[s].median for s in SENSORS}


def _covariance(columns: Dict[str, List[float]], means: List[float]) -> List[List[float]]:
    n = min(len(columns[s]) for s in SENSORS)
    cov = [[0.0] * 3 for _ in range(3)]
    for i, si in enumerate(SENSORS):
        for j, sj in enumerate(SENSORS):
            acc = 0.0
            for k in range(n):
                acc += (columns[si][k] - means[i]) * (columns[sj][k] - means[j])
            cov[i][j] = acc / max(n - 1, 1)
    # Ridge term keeps the matrix invertible on near-constant channels.
    for i in range(3):
        cov[i][i] += 1e-6
    return cov


def _invert_3x3(m: List[List[float]]) -> List[List[float]]:
    a, b, c = m[0]
    d, e, f = m[1]
    g, h, i = m[2]
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-18:
        det = 1e-18
    inv = [
        [(e * i - f * h), -(b * i - c * h), (b * f - c * e)],
        [-(d * i - f * g), (a * i - c * g), -(a * f - c * d)],
        [(d * h - e * g), -(a * h - b * g), (a * e - b * d)],
    ]
    return [[v / det for v in row] for row in inv]


def parse_timestamp(raw: Any) -> Optional[datetime]:
    if isinstance(raw, datetime):
        return raw
    if not raw:
        return None
    text = str(raw).strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


# --------------------------------------------------------------------------
# Signal record : the unified input to this module
# --------------------------------------------------------------------------

@dataclass
class SignalRecord:
    """One AWS sample, merged across Member 2 (ML) and Member 3 (temporal)."""

    index: int
    timestamp: Optional[datetime]
    values: Dict[str, float] = field(default_factory=dict)

    # Member 2 - Isolation Forest
    ml_anomaly_score: float = 0.0     # 0..100, higher = more anomalous
    ml_decision_score: Optional[float] = None
    ml_flag: bool = False

    # Member 3 - temporal / multivariate
    temporal_score: float = 0.0
    multivariate_score: float = 0.0
    spike_flag: bool = False
    drift_flag: bool = False
    frozen_flag: bool = False
    temporal_reason: str = ""

    # Data-quality observations captured at load time
    missing_sensors: List[str] = field(default_factory=list)
    sentinel_sensors: List[str] = field(default_factory=list)

    # Ground truth (only present in evaluation runs).
    # NOTE: anomaly_label in Member 1's dataset is MULTI-CLASS (0=normal,
    # 1=spike, 2=frozen, 3=drift, 4=noise_burst, 5=cross_variable), not a 0/1
    # flag. Treating it as binary silently inflates every metric.
    true_label: Optional[int] = None
    true_type: Optional[str] = None
    true_param: Optional[str] = None

    @property
    def truly_anomalous(self) -> Optional[bool]:
        if self.true_label is None:
            return None
        return self.true_label != 0

    @property
    def true_fault(self) -> Optional[str]:
        if not self.true_type:
            return None
        return GROUND_TRUTH_MAP.get(self.true_type)

    @classmethod
    def from_dict(cls, row: Dict[str, Any], index: int) -> "SignalRecord":
        values: Dict[str, float] = {}
        missing: List[str] = []
        sentinel: List[str] = []

        for sensor in SENSORS:
            raw = row.get(sensor, "")
            if raw is None or str(raw).strip().lower() in ("", "nan", "none", "null", "na"):
                missing.append(sensor)
                continue
            try:
                value = float(raw)
            except (TypeError, ValueError):
                missing.append(sensor)
                continue
            if math.isnan(value):
                missing.append(sensor)
                continue
            if any(abs(value - s) < 1e-6 for s in SENTINEL_VALUES):
                sentinel.append(sensor)
            values[sensor] = value

        return cls(
            index=index,
            timestamp=parse_timestamp(row.get("datetime")),
            values=values,
            ml_anomaly_score=_to_float(row.get("anomaly_score"), 0.0),
            ml_decision_score=_to_float_or_none(row.get("decision_score")),
            ml_flag=_to_bool(row.get("predicted_anomaly")),
            temporal_score=_to_float(row.get("temporal_score"), 0.0),
            multivariate_score=_to_float(row.get("multivariate_score"), 0.0),
            spike_flag=_to_bool(row.get("spike_detected")),
            drift_flag=_to_bool(row.get("drift_detected")),
            frozen_flag=_to_bool(row.get("frozen_sensor")),
            temporal_reason=str(row.get("temporal_reason", "") or ""),
            true_label=int(row["anomaly_label"]) if str(row.get("anomaly_label", "")).strip() not in ("", "None") else None,
            true_type=(row.get("anomaly_type") or None),
            true_param=(row.get("anomaly_param") or None),
            missing_sensors=missing,
            sentinel_sensors=sentinel,
        )


def _to_float(raw: Any, default: float = 0.0) -> float:
    try:
        value = float(raw)
        return default if math.isnan(value) else value
    except (TypeError, ValueError):
        return default


def _to_float_or_none(raw: Any) -> Optional[float]:
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def _to_bool(raw: Any) -> bool:
    return str(raw).strip().lower() in ("1", "true", "yes", "y", "t")


# --------------------------------------------------------------------------
# Evidence and results
# --------------------------------------------------------------------------

@dataclass
class Evidence:
    """One atomic reason the engine believes a fault is present."""

    check: str          # machine name, e.g. "step_magnitude"
    description: str    # human sentence for the dashboard
    observed: float
    threshold: float
    weight: float       # importance of this check within its fault class
    strength: float     # 0..1 how strongly the check fired
    sensor: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check": self.check,
            "description": self.description,
            "observed": round(self.observed, 4),
            "threshold": round(self.threshold, 4),
            "weight": self.weight,
            "strength": round(self.strength, 4),
            "sensor": self.sensor,
        }


@dataclass
class FaultCandidate:
    fault: str
    score: float                       # 0..1 belief that this fault is present
    evidence: List[Evidence] = field(default_factory=list)
    affected_sensors: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def title(self) -> str:
        return FAULT_TITLE.get(self.fault, self.fault)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fault": self.fault,
            "title": self.title,
            "score": round(self.score, 4),
            "affected_sensors": self.affected_sensors,
            "evidence": [e.to_dict() for e in self.evidence],
            "details": self.details,
        }


@dataclass
class RootCauseResult:
    record: SignalRecord
    candidates: List[FaultCandidate]    # ranked, best first
    primary: FaultCandidate
    runner_up: Optional[FaultCandidate]

    @property
    def is_fault(self) -> bool:
        return self.primary.fault != NO_FAULT

    @property
    def margin(self) -> float:
        """Separation between the winner and the second hypothesis."""
        if self.runner_up is None:
            return self.primary.score
        return max(0.0, self.primary.score - self.runner_up.score)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "primary": self.primary.to_dict(),
            "runner_up": self.runner_up.to_dict() if self.runner_up else None,
            "margin": round(self.margin, 4),
            "all_candidates": [c.to_dict() for c in self.candidates],
        }


def _blend(evidence: List[Evidence]) -> float:
    """Weighted evidence fusion -> belief in 0..1."""
    if not evidence:
        return 0.0
    total_w = sum(e.weight for e in evidence)
    if total_w <= 0:
        return 0.0
    return min(1.0, sum(e.weight * e.strength for e in evidence) / total_w)


# --------------------------------------------------------------------------
# The analyzer
# --------------------------------------------------------------------------

class RootCauseAnalyzer:
    """Turns anomaly signals into a ranked list of physical fault hypotheses."""

    def __init__(self, baseline: Baseline, config: Optional[RCAConfig] = None):
        self.baseline = baseline
        self.cfg = config or RCAConfig()
        self.maha_threshold = baseline.mahalanobis_threshold
        self.calibration_note = "Threshold from training data only."

    def calibrate_to_stream(self, records: List[SignalRecord]) -> None:
        """
        Re-estimate the joint-distance bar on the stream being analysed.

        WHY THIS IS NECESSARY: an AWS baseline is seasonal and diurnal. Training
        data captured in one part of the day sits at a different operating point
        from the data being scored, so *healthy* live readings legitimately fall
        outside the training cloud. Without this step the multivariate detector
        alarms on every normal sample.

        Median + k*MAD is used because anomalies are a minority and both
        statistics are insensitive to them - no labels are required.
        """
        distances = [
            self.baseline.mahalanobis(r.values)
            for r in records if len(r.values) == len(SENSORS)
        ]
        if len(distances) < 50:
            return
        centre = _median(distances)
        spread = max(_mad(distances, centre), 1e-6)
        adaptive = centre + self.cfg.maha_stream_k * spread
        self.maha_threshold = max(self.baseline.mahalanobis_threshold, adaptive)
        self.calibration_note = (
            f"Joint-distance bar re-estimated on the live stream: "
            f"median {centre:.1f} + {self.cfg.maha_stream_k:.0f}x MAD {spread:.1f} "
            f"= {self.maha_threshold:.1f} sigma."
        )

    # -- public API ---------------------------------------------------------

    def analyze(self, record: SignalRecord, history: List[SignalRecord]) -> RootCauseResult:
        """
        history = records BEFORE this one (oldest .. newest), already analysed
        or at least parsed. Only past data is used, so this works on a live
        stream exactly as it does on a CSV replay.
        """
        candidates = [
            self._check_communication(record, history),
            self._check_spike(record, history),
            self._check_frozen(record, history),
            self._check_drift(record, history),
            self._check_multivariate(record, history),
        ]

        candidates = [c for c in candidates if c.score > 0.0]
        candidates = self._explain_away(candidates)
        candidates.sort(key=lambda c: c.score, reverse=True)

        strong = [c for c in candidates if c.score >= self.cfg.min_fault_score]

        if strong:
            primary = strong[0]
            runner_up = strong[1] if len(strong) > 1 else (candidates[1] if len(candidates) > 1 else None)
        elif self.cfg.enable_ml_only_alarms and self._ml_says_anomaly(record):
            # The model is confident but no physical rule matched. Say so
            # instead of inventing a fault - honest failure beats a wrong label.
            primary = FaultCandidate(
                fault=UNKNOWN_ANOMALY,
                score=min(1.0, record.ml_anomaly_score / 100.0),
                evidence=[
                    Evidence(
                        check="ml_only_detection",
                        description=(
                            f"Isolation Forest scored this sample {record.ml_anomaly_score:.1f}/100 "
                            "but no temporal or physical rule matched a known fault signature."
                        ),
                        observed=record.ml_anomaly_score,
                        threshold=self.cfg.ml_anomaly_score_threshold,
                        weight=1.0,
                        strength=min(1.0, record.ml_anomaly_score / 100.0),
                    )
                ],
                details={"note": "Needs manual review or a new rule."},
            )
            runner_up = candidates[0] if candidates else None
        else:
            primary = FaultCandidate(
                fault=NO_FAULT,
                score=0.0,
                evidence=[],
                details={"note": "All detectors below threshold."},
            )
            runner_up = candidates[0] if candidates else None

        return RootCauseResult(
            record=record,
            candidates=candidates,
            primary=primary,
            runner_up=runner_up,
        )

    def analyze_stream(self, records: List[SignalRecord]) -> List[RootCauseResult]:
        self.calibrate_to_stream(records)
        results: List[RootCauseResult] = []
        for i, rec in enumerate(records):
            results.append(self.analyze(rec, records[:i]))
        return results

    def _explain_away(self, candidates: List[FaultCandidate]) -> List[FaultCandidate]:
        """
        Causal precedence between hypotheses.

        A large spike or an advancing drift MECHANICALLY pushes the joint
        (T, P, RH) vector away from the healthy cloud, so the multivariate
        detector fires as a SIDE EFFECT. Reporting "cross-variable
        inconsistency" there would name the symptom instead of the cause.

        So when a single-channel fault already accounts for the same sensor,
        the multivariate hypothesis is demoted. A genuine cross-variable fault
        (every channel individually normal) is never demoted, because no
        single-channel fault can explain it.
        """
        by_fault = {c.fault: c for c in candidates}
        multi = by_fault.get(MULTIVARIATE_ANOMALY)
        if multi is None:
            return candidates

        # Reverse precedence. A genuine cross-variable fault sits far from the
        # healthy cloud while every channel stays individually normal. No
        # single-channel fault can produce that, so here the multivariate
        # hypothesis is the cause and any concurrent drift/spike reading is the
        # side effect - the demotion runs the other way.
        if multi.details.get("subtype") == "cross_variable":
            distance = multi.details.get("mahalanobis", 0.0)
            if (multi.score >= self.cfg.min_fault_score
                    and distance >= self.cfg.cross_var_dominance * self.maha_threshold):
                for symptom in (DRIFT, SPIKE):
                    other = by_fault.get(symptom)
                    if other is not None:
                        other.score *= self.cfg.explain_away_factor
                        other.details["explained_away_by"] = MULTIVARIATE_ANOMALY
                        other.details["explain_away_note"] = (
                            "Every channel is individually within limits, so a single-channel "
                            "fault cannot account for the joint displacement."
                        )
            return candidates

        for cause in (SPIKE, DRIFT, FROZEN_SENSOR, COMMUNICATION_FAILURE):
            other = by_fault.get(cause)
            if other is None or other.score < self.cfg.min_fault_score:
                continue
            if set(other.affected_sensors) & set(multi.affected_sensors) or not multi.affected_sensors:
                multi.score *= self.cfg.explain_away_factor
                multi.details["explained_away_by"] = cause
                multi.details["explain_away_note"] = (
                    f"Joint-distance displacement is a consequence of the "
                    f"{FAULT_TITLE[cause].lower()} on the same channel."
                )
                break
        return candidates

    # -- individual detectors ----------------------------------------------

    def _ml_says_anomaly(self, record: SignalRecord) -> bool:
        """
        Should an ML detection with NO matching rule still raise an alarm?

        Only when the model is very confident, and either another module also
        saw something or the model is near-certain on its own.
        """
        score = record.ml_anomaly_score
        if score >= self.cfg.ml_unknown_solo_threshold:
            return True
        corroborated = (
            record.temporal_score >= 0.5
            or record.multivariate_score >= 0.6
            or record.spike_flag or record.drift_flag or record.frozen_flag
        )
        return score >= self.cfg.ml_unknown_threshold and corroborated

    # 1. COMMUNICATION FAILURE ---------------------------------------------
    def _check_communication(self, record: SignalRecord, history: List[SignalRecord]) -> FaultCandidate:
        evidence: List[Evidence] = []
        affected: List[str] = []
        details: Dict[str, Any] = {}

        nominal = self.baseline.sampling_interval_s
        gap_limit = nominal * self.cfg.comm_gap_factor

        # (a) Lost packets - the clock jumped further than the sampling period.
        if history and record.timestamp and history[-1].timestamp:
            gap = (record.timestamp - history[-1].timestamp).total_seconds()
            details["gap_seconds"] = gap
            if gap > gap_limit:
                lost = max(0, int(round(gap / nominal)) - 1)
                details["estimated_lost_samples"] = lost
                evidence.append(Evidence(
                    check="transmission_gap",
                    description=(
                        f"Data gap of {gap:.0f} s against a nominal {nominal:.0f} s interval - "
                        f"approximately {lost} sample(s) never reached the server."
                    ),
                    observed=gap,
                    threshold=gap_limit,
                    weight=1.0,
                    strength=min(1.0, (gap / nominal - 1.0) / 5.0),
                ))
            elif gap <= 0:
                evidence.append(Evidence(
                    check="timestamp_disorder",
                    description=f"Timestamp did not advance (delta = {gap:.0f} s): duplicate or out-of-order packet.",
                    observed=gap,
                    threshold=1.0,
                    weight=0.6,
                    strength=0.7,
                ))

        # (b) Blank / NaN fields in the telemetry frame.
        if record.missing_sensors:
            affected.extend(record.missing_sensors)
            evidence.append(Evidence(
                check="missing_fields",
                description=(
                    "Empty or non-numeric value(s) received for "
                    + ", ".join(SENSOR_LABEL[s] for s in record.missing_sensors) + "."
                ),
                observed=float(len(record.missing_sensors)),
                threshold=1.0,
                weight=1.0,
                strength=min(1.0, len(record.missing_sensors) / len(SENSORS) + 0.5),
            ))

        # (c) Datalogger sentinel values such as -999.
        if record.sentinel_sensors:
            affected.extend(record.sentinel_sensors)
            evidence.append(Evidence(
                check="sentinel_value",
                description=(
                    "Datalogger error code transmitted on "
                    + ", ".join(SENSOR_LABEL[s] for s in record.sentinel_sensors) + "."
                ),
                observed=float(len(record.sentinel_sensors)),
                threshold=1.0,
                weight=1.0,
                strength=1.0,
            ))

        # (d) Every channel frozen at once = link holding the last frame,
        #     which is a telemetry fault rather than a sensor fault.
        if len(record.values) == len(SENSORS):
            runs = {s: self._constant_run(record, history, s) for s in SENSORS}
            if all(r >= self.cfg.frozen_min_run for r in runs.values()):
                details["all_channel_run"] = min(runs.values())
                affected.extend(SENSORS)
                evidence.append(Evidence(
                    check="all_channels_static",
                    description=(
                        f"All three channels have been byte-identical for {min(runs.values())} consecutive "
                        "frames - typical of a link repeating the last good packet."
                    ),
                    observed=float(min(runs.values())),
                    threshold=float(self.cfg.frozen_min_run),
                    weight=0.9,
                    strength=min(1.0, min(runs.values()) / (self.cfg.frozen_min_run * 2)),
                ))

        return FaultCandidate(
            fault=COMMUNICATION_FAILURE,
            score=_blend(evidence),
            evidence=evidence,
            affected_sensors=sorted(set(affected)),
            details=details,
        )

    # 2. SPIKE --------------------------------------------------------------
    def _check_spike(self, record: SignalRecord, history: List[SignalRecord]) -> FaultCandidate:
        evidence: List[Evidence] = []
        affected: List[str] = []
        details: Dict[str, Any] = {}

        if not history:
            return FaultCandidate(SPIKE, 0.0, [], [], {"note": "No previous sample."})

        previous = history[-1]
        before = history[-2] if len(history) >= 2 else None
        worst = 0.0
        recoveries: List[str] = []

        for sensor in SENSORS:
            if sensor not in record.values or sensor not in previous.values:
                continue
            step = abs(record.values[sensor] - previous.values[sensor])
            scale = self.baseline.sensors[sensor].step_sigma
            sigmas = step / scale
            details[f"{sensor}_step_sigmas"] = round(sigmas, 2)

            if sigmas < self.cfg.spike_sigma:
                continue

            # Is this the FALL of an impulse rather than a new one? An impulse
            # always produces two large steps (out and back). Without this
            # check every spike would be reported twice and the clean sample
            # after it would be blamed for the previous sample's fault.
            if before is not None and sensor in before.values:
                out_step = abs(previous.values[sensor] - before.values[sensor]) / scale
                returned = abs(record.values[sensor] - before.values[sensor]) / scale
                if out_step >= self.cfg.spike_sigma and returned <= self.cfg.spike_recovery_sigma:
                    recoveries.append(sensor)
                    continue

            affected.append(sensor)
            worst = max(worst, sigmas)
            evidence.append(Evidence(
                check="step_magnitude",
                description=(
                    f"{SENSOR_LABEL[sensor]} jumped {step:.2f} {SENSOR_UNIT[sensor]} in one sampling "
                    f"interval - {sigmas:.1f}x the largest movement ever seen on this channel in "
                    "healthy data."
                ),
                observed=sigmas,
                threshold=self.cfg.spike_sigma,
                weight=1.0,
                strength=min(1.0, sigmas / (self.cfg.spike_sigma * 2)),
                sensor=sensor,
            ))

        if recoveries and not evidence:
            details["subtype"] = "spike_recovery"
            details["recovered_sensors"] = recoveries
            return FaultCandidate(
                SPIKE, 0.0, [], [],
                {**details, "note": "Return-to-normal edge of the previous impulse; not a new fault."},
            )

        if not evidence:
            return FaultCandidate(SPIKE, 0.0, [], [], details)


        # Local roughness REFINEMENT (subtype only, never a trigger).
        # Measured on this dataset, roughness does not separate a noise burst
        # from normal data: the sliding window bleeds energy from neighbouring
        # spikes, so healthy rows reach a 90th-percentile roughness of 4.8
        # against 1.0 for real bursts. Used as a trigger it produced 369 false
        # alarms. It is therefore only used to label an ALREADY-confirmed spike
        # as isolated or burst-like.
        rough_window = history[-self.cfg.volatility_window:] + [record]
        for sensor in list(affected):
            series = [r.values[sensor] for r in rough_window if sensor in r.values]
            if len(series) < self.cfg.volatility_window:
                continue
            roughness = statistics.fmean(
                [abs(series[i] - series[i - 1]) for i in range(1, len(series))]
            )
            ratio = roughness / self.baseline.sensors[sensor].volatility_scale
            details[f"{sensor}_roughness_ratio"] = round(ratio, 2)

        # Repeated impulses inside a short window = noise burst, not one spike.
        window = history[-self.cfg.burst_window:]
        burst_count = sum(1 for r in window if r.spike_flag) + 1
        if burst_count >= self.cfg.burst_min_spikes:
            details["subtype"] = "noise_burst"
            details["spikes_in_window"] = burst_count
            evidence.append(Evidence(
                check="burst_density",
                description=(
                    f"{burst_count} impulse events within the last {self.cfg.burst_window} samples - "
                    "signature of an electrical noise burst rather than a single outlier."
                ),
                observed=float(burst_count),
                threshold=float(self.cfg.burst_min_spikes),
                weight=0.7,
                strength=min(1.0, burst_count / (self.cfg.burst_min_spikes * 2)),
            ))
        else:
            details["subtype"] = "isolated_spike"

        # Corroboration from Member 3's independent temporal detector.
        if record.spike_flag:
            evidence.append(Evidence(
                check="temporal_module_agreement",
                description="The time-series module independently flagged a spike on this sample.",
                observed=record.temporal_score,
                threshold=1.0,
                weight=0.5,
                strength=max(0.6, min(1.0, record.temporal_score)),
            ))

        details["max_step_sigmas"] = round(worst, 2)
        return FaultCandidate(SPIKE, _blend(evidence), evidence, sorted(set(affected)), details)

    # 3. FROZEN SENSOR ------------------------------------------------------
    def _constant_run(self, record: SignalRecord, history: List[SignalRecord], sensor: str) -> int:
        """How many consecutive frames (including now) carry an identical value."""
        if sensor not in record.values:
            return 0
        run = 1
        value = record.values[sensor]
        for past in reversed(history):
            if sensor not in past.values:
                break
            if abs(past.values[sensor] - value) <= self.cfg.frozen_tolerance:
                run += 1
            else:
                break
        return run

    def _check_frozen(self, record: SignalRecord, history: List[SignalRecord]) -> FaultCandidate:
        evidence: List[Evidence] = []
        affected: List[str] = []
        details: Dict[str, Any] = {}

        for sensor in SENSORS:
            run = self._constant_run(record, history, sensor)
            sb = self.baseline.sensors[sensor]
            bar = sb.run_bar(self.cfg.frozen_min_run)
            details[f"{sensor}_run"] = run
            details[f"{sensor}_run_bar"] = round(bar, 1)

            if run >= bar:
                affected.append(sensor)
                surprise = sb.run_surprise(run)
                minutes = run * self.baseline.sampling_interval_s / 60.0
                evidence.append(Evidence(
                    check="constant_value_run",
                    description=(
                        f"{SENSOR_LABEL[sensor]} has reported exactly {record.values[sensor]:.2f} "
                        f"{SENSOR_UNIT[sensor]} for {run} consecutive samples ({minutes:.0f} min). "
                        f"Only {(1 - surprise) * 100:.1f}% of healthy runs on this channel last that long."
                    ),
                    observed=float(run),
                    threshold=bar,
                    weight=1.0,
                    strength=surprise,
                    sensor=sensor,
                ))

        if not evidence:
            return FaultCandidate(FROZEN_SENSOR, 0.0, [], [], details)

        # A genuinely stuck channel is suspicious precisely because the OTHER
        # channels are still moving; that rules out "the weather went calm".
        moving = self._moving_channels(record, history, exclude=affected)
        if moving:
            evidence.append(Evidence(
                check="peer_channels_active",
                description=(
                    "Meanwhile " + ", ".join(SENSOR_LABEL[s] for s in moving) +
                    " continued to vary normally, so the flat trace is not calm weather."
                ),
                observed=float(len(moving)),
                threshold=1.0,
                weight=0.8,
                strength=1.0,
            ))

        if record.frozen_flag:
            evidence.append(Evidence(
                check="temporal_module_agreement",
                description="The time-series module independently flagged a frozen channel here.",
                observed=1.0,
                threshold=1.0,
                weight=0.4,
                strength=1.0,
            ))

        return FaultCandidate(FROZEN_SENSOR, _blend(evidence), evidence, sorted(set(affected)), details)

    def _moving_channels(self, record: SignalRecord, history: List[SignalRecord],
                         exclude: Sequence[str]) -> List[str]:
        moving = []
        window = history[-self.cfg.frozen_min_run:]
        for sensor in SENSORS:
            if sensor in exclude or sensor not in record.values:
                continue
            series = [r.values[sensor] for r in window if sensor in r.values]
            if len(series) >= 3 and (max(series) - min(series)) > self.baseline.sensors[sensor].step_sigma:
                moving.append(sensor)
        return moving

    # 4. DRIFT --------------------------------------------------------------
    def _check_drift(self, record: SignalRecord, history: List[SignalRecord]) -> FaultCandidate:
        evidence: List[Evidence] = []
        affected: List[str] = []
        details: Dict[str, Any] = {}

        window_len = self.cfg.drift_window
        if len(history) < window_len:
            return FaultCandidate(DRIFT, 0.0, [], [], {"note": "Warming up drift window."})

        window = history[-(window_len - 1):] + [record]

        for sensor in SENSORS:
            raw_series = [r.values[sensor] for r in window if sensor in r.values]
            if len(raw_series) < window_len * 0.8:
                continue

            # Median-filter the window before measuring drift. A single spike
            # inside the window otherwise drags the mean and gets reported as
            # "drift" - on the validation set a 4.8 degC spike produced a
            # 20-sigma phantom drift. A 3-point median removes impulses while
            # preserving a genuine ramp.
            series = _median_filter(raw_series, 3)

            sb = self.baseline.sensors[sensor]
            window_mean = statistics.fmean(series)
            # Compare the WINDOW LEVEL against how far window means naturally
            # wander, not against the spread of single readings.
            offset_sigmas = abs(window_mean - sb.median) / sb.window_mean_sigma
            slope = _least_squares_slope(series)          # units per sample

            # Level and endpoints come from the median-filtered series so a
            # spike cannot fake a ramp. Total travel is measured on the RAW
            # series on purpose: smoothing removes jitter and would inflate the
            # monotonicity ratio, which tripled false drift alarms in testing.
            # Keeping raw travel also penalises any window containing impulsive
            # energy, which is exactly what a clean drift does not have.
            net = series[-1] - series[0]
            travel = sum(abs(raw_series[i] - raw_series[i - 1]) for i in range(1, len(raw_series)))
            monotonic = abs(net) / travel if travel > 1e-9 else 0.0

            details[f"{sensor}_offset_sigmas"] = round(offset_sigmas, 2)
            details[f"{sensor}_slope_per_sample"] = round(slope, 6)
            details[f"{sensor}_monotonicity"] = round(monotonic, 3)

            net_sigmas = abs(net) / sb.sigma
            details[f"{sensor}_net_sigmas"] = round(net_sigmas, 2)

            # A drift must (a) sit away from the calibrated baseline, (b) move
            # in one consistent direction, and (c) actually travel a material
            # distance within the window. Requiring all three stops a steady
            # diurnal offset from being reported as instrument drift.
            if (offset_sigmas >= self.cfg.drift_sigma
                    and monotonic >= self.cfg.drift_monotonic_ratio
                    and net_sigmas >= self.cfg.drift_min_net_sigma):
                affected.append(sensor)
                direction = "upward" if net > 0 else "downward"
                per_hour = slope * (3600.0 / max(self.baseline.sampling_interval_s, 1e-6))
                details[f"{sensor}_drift_per_hour"] = round(per_hour, 4)
                evidence.append(Evidence(
                    check="baseline_offset",
                    description=(
                        f"{SENSOR_LABEL[sensor]} has averaged {window_mean:.2f} {SENSOR_UNIT[sensor]} "
                        f"over the last {len(series)} samples, {offset_sigmas:.1f} sigma away from its "
                        f"calibrated baseline of {sb.median:.2f} {SENSOR_UNIT[sensor]}."
                    ),
                    observed=offset_sigmas,
                    threshold=self.cfg.drift_sigma,
                    weight=1.0,
                    strength=min(1.0, offset_sigmas / (self.cfg.drift_sigma * 2)),
                    sensor=sensor,
                ))
                evidence.append(Evidence(
                    check="monotonic_trend",
                    description=(
                        f"The movement is consistently {direction} ({monotonic:.0%} of the travel is net "
                        f"displacement, about {per_hour:+.2f} {SENSOR_UNIT[sensor]}/hour), which separates "
                        "calibration drift from random fluctuation."
                    ),
                    observed=monotonic,
                    threshold=self.cfg.drift_monotonic_ratio,
                    weight=0.9,
                    strength=min(1.0, monotonic / 0.7),
                    sensor=sensor,
                ))

        if not evidence:
            return FaultCandidate(DRIFT, 0.0, [], [], details)

        if record.drift_flag:
            evidence.append(Evidence(
                check="temporal_module_agreement",
                description="The time-series module independently flagged drift on this sample.",
                observed=1.0,
                threshold=1.0,
                weight=0.4,
                strength=1.0,
            ))

        return FaultCandidate(DRIFT, _blend(evidence), evidence, sorted(set(affected)), details)

    # 5. MULTIVARIATE -------------------------------------------------------
    def _check_multivariate(self, record: SignalRecord, history: List[SignalRecord]) -> FaultCandidate:
        evidence: List[Evidence] = []
        affected: List[str] = []
        details: Dict[str, Any] = {}

        if len(record.values) < len(SENSORS):
            return FaultCandidate(MULTIVARIATE_ANOMALY, 0.0, [], [], {"note": "Incomplete frame."})

        # (a) Hard physical limits.
        for sensor, (lo, hi) in PHYSICAL_LIMITS.items():
            value = record.values[sensor]
            if value < lo or value > hi:
                affected.append(sensor)
                evidence.append(Evidence(
                    check="physical_limit",
                    description=(
                        f"{SENSOR_LABEL[sensor]} of {value:.2f} {SENSOR_UNIT[sensor]} is outside the "
                        f"physically possible range {lo} to {hi} {SENSOR_UNIT[sensor]}."
                    ),
                    observed=value,
                    threshold=hi if value > hi else lo,
                    weight=1.0,
                    strength=1.0,
                    sensor=sensor,
                ))

        # (b) Joint distance from the healthy cloud.
        distance = self.baseline.mahalanobis(record.values)
        z_scores = {s: self.baseline.z_score(s, record.values[s]) for s in SENSORS}
        max_abs_z = max(abs(z) for z in z_scores.values())
        details["mahalanobis"] = round(distance, 3)
        details["z_scores"] = {s: round(z, 2) for s, z in z_scores.items()}

        maha_bar = self.maha_threshold
        details["mahalanobis_threshold"] = round(maha_bar, 3)

        if distance >= maha_bar:
            evidence.append(Evidence(
                check="joint_distance",
                description=(
                    f"The joint (temperature, pressure, humidity) reading sits {distance:.1f} sigma from "
                    "the station's healthy operating cloud."
                ),
                observed=distance,
                threshold=maha_bar,
                weight=1.0,
                strength=min(1.0, distance / (maha_bar * 2)),
            ))
            # The signature of a true cross-variable fault: nothing looks wrong
            # in isolation, only the combination does.
            if max_abs_z <= self.cfg.cross_var_univariate_max:
                details["subtype"] = "cross_variable"
                affected.extend(SENSORS)
                evidence.append(Evidence(
                    check="cross_variable_inconsistency",
                    description=(
                        f"Every channel is individually within normal limits (max {max_abs_z:.1f} sigma), "
                        "so the fault is in the relationship between them, not in any single sensor."
                    ),
                    observed=max_abs_z,
                    threshold=self.cfg.cross_var_univariate_max,
                    weight=1.0,
                    strength=min(1.0, distance / (maha_bar * 1.5)),
                ))
            else:
                details["subtype"] = "single_channel_outlier"
                affected.append(max(z_scores, key=lambda s: abs(z_scores[s])))

        # (c) Corroboration from Member 3's multivariate score.
        if record.multivariate_score >= 0.8 and evidence:
            evidence.append(Evidence(
                check="multivariate_module_agreement",
                description=(
                    f"The multivariate module scored this combination {record.multivariate_score:.2f}/1.00."
                ),
                observed=record.multivariate_score,
                threshold=0.8,
                weight=0.5,
                strength=record.multivariate_score,
            ))

        return FaultCandidate(
            fault=MULTIVARIATE_ANOMALY,
            score=_blend(evidence),
            evidence=evidence,
            affected_sensors=sorted(set(affected)),
            details=details,
        )


def _median_filter(series: Sequence[float], width: int = 3) -> List[float]:
    """Impulse-resistant smoothing; preserves ramps, removes spikes."""
    if width < 2 or len(series) < width:
        return list(series)
    half = width // 2
    out: List[float] = []
    for i in range(len(series)):
        lo = max(0, i - half)
        hi = min(len(series), i + half + 1)
        out.append(statistics.median(series[lo:hi]))
    return out


def _least_squares_slope(series: Sequence[float]) -> float:
    n = len(series)
    if n < 2:
        return 0.0
    mean_x = (n - 1) / 2.0
    mean_y = statistics.fmean(series)
    num = sum((i - mean_x) * (y - mean_y) for i, y in enumerate(series))
    den = sum((i - mean_x) ** 2 for i in range(n))
    return num / den if den else 0.0


# --------------------------------------------------------------------------
# Convenience loaders
# --------------------------------------------------------------------------

def load_csv(path: str) -> List[Dict[str, Any]]:
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def load_baseline(train_csv: str, config: Optional[RCAConfig] = None) -> Baseline:
    return Baseline.from_rows(load_csv(train_csv), config)


def records_from_csv(path: str) -> List[SignalRecord]:
    return [SignalRecord.from_dict(row, i) for i, row in enumerate(load_csv(path))]


# --------------------------------------------------------------------------
# Self-test
# --------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Usage: python root_cause.py <train_raw.csv> <signals.csv>")
        raise SystemExit(1)

    baseline = load_baseline(sys.argv[1])
    records = records_from_csv(sys.argv[2])
    analyzer = RootCauseAnalyzer(baseline)
    results = analyzer.analyze_stream(records)

    counts: Dict[str, int] = {}
    for r in results:
        counts[r.primary.fault] = counts.get(r.primary.fault, 0) + 1

    print(f"Baseline: {baseline.n_rows} rows, nominal interval {baseline.sampling_interval_s:.0f}s")
    print(f"Analysed {len(results)} samples\n")
    for fault, n in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {fault:<24} {n:>5}")

    print("\nFirst 3 detected faults:")
    shown = 0
    for r in results:
        if r.is_fault and shown < 3:
            shown += 1
            print(f"\n[{r.record.timestamp}] {r.primary.title}  score={r.primary.score:.2f}")
            for e in r.primary.evidence:
                print(f"    - {e.description}")
