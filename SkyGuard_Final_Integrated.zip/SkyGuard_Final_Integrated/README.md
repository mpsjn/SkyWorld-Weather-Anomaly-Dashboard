# SkyGuard AI — Integrated SIH 2026 (PS 26073)

A single-folder integration of the team's AWS anomaly-detection modules.

## Included
- Isolation Forest ML detector
- Batch prediction adapter
- Temporal + multivariate analysis
- Root-cause diagnosis
- Exact Shapley explainability
- Confidence and severity scoring
- Ground-truth evaluation
- Integrated pipeline
- Streamlit dashboard
- Original datasets, model, metrics and plots

## Setup (Mac/Linux)
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run everything
```bash
python run_pipeline.py
```

Generated outputs are written directly in this same folder; no output subfolders are required.

## Run dashboard
```bash
python -m streamlit run app.py
```
Then open the local URL shown by Streamlit (normally `http://localhost:8501`).

## Run individual modules
```bash
python train_model.py
python predict.py
python member3_temporal_multivariate_analysis.py train_raw.csv test_with_anomalies.csv member3_anomaly_signals_integrated.csv
python diagnosis.py --train train_raw.csv --ml test_predictions_integrated.csv --temporal member3_anomaly_signals_integrated.csv --outdir . --evaluate
```

The original modules are retained; the integration adds only the shared launcher, batch adapter, and dashboard, plus root-level artifact paths so the final project stays flat.
