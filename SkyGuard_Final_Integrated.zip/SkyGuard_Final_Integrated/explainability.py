"""
SkyGuard / PS 26073 - AI-ML Based Intelligent Anomaly Detection for AWS
=======================================================================
Member 4 - Module 2 of 4 :  EXPLAINABILITY

An IMD field engineer will not act on "anomaly_score = 87.3". This module
turns a detection into something a human can audit and act on:

    1. WHY was it detected?        -> the ordered rule trace that fired
    2. WHICH features contributed? -> signed per-channel attribution
    3. SHAP analysis               -> exact Shapley values over the 3 channels
    4. Human-readable explanation  -> a short paragraph in plain English

On Shapley values
-----------------
The station has exactly 3 features, so the 2^3 = 8 coalitions can be
enumerated EXACTLY. There is no need to approximate with KernelSHAP sampling,
which is what the `shap` library would do. The exact computation is both
faster and free of sampling error here.

    phi_i = SUM over S subset of F\\{i} of
                |S|! (|F|-|S|-1)! / |F|!  *  [ v(S + i) - v(S) ]

`v(S)` is the anomaly score of a point where the channels in S keep their
observed values and the channels outside S are marginalised over a background
sample of healthy data. This is the standard interventional SHAP formulation.

Shapley values satisfy EFFICIENCY: sum(phi) = v(all features) - v(no
features). The module asserts this, so the attribution shown on the dashboard
is provably complete - no contribution is invented or lost.

If the `shap` library is installed AND a scikit-learn model is supplied, the
module will use TreeSHAP on the real Isolation Forest instead. Otherwise it
falls back to the exact computation above, which needs no dependencies.

Author : Member 4 (Diagnosis & Explainability)
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from itertools import combinations
from typing import Any, Callable, Dict, List, Optional, Sequence

from root_cause import (
    COMMUNICATION_FAILURE,
    DRIFT,
    FROZEN_SENSOR,
    MULTIVARIATE_ANOMALY,
    NO_FAULT,
    SENSOR_LABEL,
    SENSOR_UNIT,
    SENSORS,
    SPIKE,
    UNKNOWN_ANOMALY,
    Baseline,
    Evidence,
    RootCauseResult,
    SignalRecord,
)

try:  # optional, never required
    import shap  # type: ignore
    _SHAP_AVAILABLE = True
except Exception:  # pragma: no cover
    shap = None
    _SHAP_AVAILABLE = False


# --------------------------------------------------------------------------
# Data structures
# --------------------------------------------------------------------------

@dataclass
class FeatureContribution:
    """How much one sensor channel is responsible for this detection."""

    feature: str
    label: str
    value: float
    unit: str
    shap_value: float          # signed; positive pushes towards "anomalous"
    contribution_pct: float    # share of the total absolute attribution
    deviation_sigma: float     # how far from the healthy baseline
    direction: str             # "above" / "below" / "at"
    rule_support: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "feature": self.feature,
            "label": self.label,
            "value": round(self.value, 3),
            "unit": self.unit,
            "shap_value": round(self.shap_value, 4),
            "contribution_pct": round(self.contribution_pct, 1),
            "deviation_sigma": round(self.deviation_sigma, 2),
            "direction": self.direction,
            "rule_support": self.rule_support,
        }


@dataclass
class Explanation:
    headline: str
    why_detected: List[str]
    feature_contributions: List[FeatureContribution]
    detector_agreement: Dict[str, Any]
    narrative: str
    technical_trace: List[Dict[str, Any]]
    shap_method: str
    shap_efficiency_error: float
    limitations: List[str] = field(default_factory=list)

    @property
    def top_feature(self) -> Optional[FeatureContribution]:
        return self.feature_contributions[0] if self.feature_contributions else None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "headline": self.headline,
            "why_detected": self.why_detected,
            "feature_contributions": [f.to_dict() for f in self.feature_contributions],
            "detector_agreement": self.detector_agreement,
            "narrative": self.narrative,
            "shap": {
                "method": self.shap_method,
                "values": {f.feature: round(f.shap_value, 4) for f in self.feature_contributions},
                "efficiency_error": round(self.shap_efficiency_error, 6),
            },
            "technical_trace": self.technical_trace,
            "limitations": self.limitations,
        }


# --------------------------------------------------------------------------
# Exact Shapley engine
# --------------------------------------------------------------------------

class ShapleyExplainer:
    """
    Exact interventional Shapley values over the station's sensor channels.

    The default value function is the Mahalanobis distance from the healthy
    operating cloud - the same quantity the multivariate detector uses, so the
    attribution explains the actual decision rather than a proxy model.
    """

    def __init__(
        self,
        baseline: Baseline,
        background: Optional[List[Dict[str, float]]] = None,
        score_fn: Optional[Callable[[Dict[str, float]], float]] = None,
        background_size: int = 48,
        seed: int = 42,
    ):
        self.baseline = baseline
        self.score_fn = score_fn or baseline.mahalanobis
        rng = random.Random(seed)

        if background:
            pool = background
            self.background = (
                rng.sample(pool, background_size) if len(pool) > background_size else list(pool)
            )
        else:
            # Synthesise a healthy background from the baseline statistics.
            self.background = [
                {
                    s: rng.gauss(self.baseline.sensors[s].median, self.baseline.sensors[s].sigma)
                    for s in SENSORS
                }
                for _ in range(background_size)
            ]

        self.method = "exact_shapley_mahalanobis"

    # -- value function -----------------------------------------------------

    def _value(self, coalition: Sequence[str], observed: Dict[str, float]) -> float:
        """E[ score(x) ] with features in `coalition` fixed to observed values."""
        total = 0.0
        for bg in self.background:
            point = {s: (observed[s] if s in coalition else bg[s]) for s in SENSORS}
            total += self.score_fn(point)
        return total / len(self.background)

    # -- exact Shapley ------------------------------------------------------

    def explain(self, observed: Dict[str, float]) -> Dict[str, float]:
        n = len(SENSORS)
        cache: Dict[frozenset, float] = {}

        def value(subset: frozenset) -> float:
            if subset not in cache:
                cache[subset] = self._value(tuple(subset), observed)
            return cache[subset]

        phi: Dict[str, float] = {}
        for i, feature in enumerate(SENSORS):
            others = [s for s in SENSORS if s != feature]
            total = 0.0
            for size in range(len(others) + 1):
                weight = (
                    math.factorial(size)
                    * math.factorial(n - size - 1)
                    / math.factorial(n)
                )
                for subset in combinations(others, size):
                    s_set = frozenset(subset)
                    total += weight * (value(s_set | {feature}) - value(s_set))
            phi[feature] = total

        # Efficiency check: the attributions must sum to the full score gap.
        self.last_efficiency_error = abs(
            sum(phi.values())
            - (value(frozenset(SENSORS)) - value(frozenset()))
        )
        return phi

    # -- optional real-SHAP path -------------------------------------------

    @staticmethod
    def library_available() -> bool:
        return _SHAP_AVAILABLE


class TreeShapExplainer(ShapleyExplainer):
    """Uses the installed `shap` package on the real Isolation Forest, if present."""

    def __init__(self, model, baseline: Baseline, background=None, **kwargs):
        super().__init__(baseline, background=background, **kwargs)
        if not _SHAP_AVAILABLE:
            raise RuntimeError("shap is not installed; use ShapleyExplainer instead.")
        self._explainer = shap.TreeExplainer(model)
        self.method = "treeshap_isolation_forest"

    def explain(self, observed: Dict[str, float]) -> Dict[str, float]:
        row = [[observed[s] for s in SENSORS]]
        values = self._explainer.shap_values(row)[0]
        # Isolation Forest scores are LOW for anomalies, so flip the sign to
        # keep "positive = pushes towards anomalous" across both back-ends.
        phi = {s: -float(v) for s, v in zip(SENSORS, values)}
        self.last_efficiency_error = 0.0
        return phi


# --------------------------------------------------------------------------
# The explainer
# --------------------------------------------------------------------------

# Plain-English opening line per fault class.
FAULT_NARRATIVE = {
    SPIKE: (
        "A single sample jumped far beyond anything this channel does naturally and then "
        "returned. That is the signature of an electrical impulse or a loose connection, "
        "not a real change in the weather."
    ),
    FROZEN_SENSOR: (
        "The channel has stopped responding and is repeating one value while the other "
        "channels continue to vary. This usually means an iced-over, blocked or "
        "electrically dead sensing element."
    ),
    DRIFT: (
        "The channel is slowly and consistently moving away from its calibrated baseline. "
        "Readings still look plausible, which is what makes drift dangerous - it "
        "quietly biases every observation until the sensor is recalibrated."
    ),
    COMMUNICATION_FAILURE: (
        "The problem is in the telemetry path rather than the sensors. Samples are "
        "missing, malformed, or repeated, so the record for this period is incomplete."
    ),
    MULTIVARIATE_ANOMALY: (
        "Every channel is individually within its normal range, but the COMBINATION is "
        "physically implausible for this station. That points to a cross-wiring, a "
        "channel-mapping error, or one sensor failing in a way that stays in range."
    ),
    UNKNOWN_ANOMALY: (
        "The machine-learning model finds this sample statistically unusual, but it does "
        "not match any known fault signature. It is being surfaced for human review "
        "rather than being forced into a category."
    ),
    NO_FAULT: "All detectors agree that this sample is consistent with healthy operation.",
}

# A MULTIVARIATE_ANOMALY has two very different meanings. Using the
# cross-variable wording for a single-channel outlier produced a self-
# contradictory report ("every channel is in range" next to a 55-sigma
# temperature), so the subtype selects the wording.
MULTIVARIATE_SUBTYPE_NARRATIVE = {
    "cross_variable": FAULT_NARRATIVE[MULTIVARIATE_ANOMALY],
    "single_channel_outlier": (
        "The joint sensor reading is far outside the station's normal operating cloud, "
        "and the displacement is dominated by one channel rather than by the "
        "relationship between them. Treat this as a single-channel failure."
    ),
}

MULTIVARIATE_SUBTYPE_TITLE = {
    "cross_variable": "Cross-variable inconsistency",
    "single_channel_outlier": "Single-channel outlier",
}

MAINTENANCE_HINT = {
    SPIKE: "Inspect cabling, connectors and grounding at the sensor head.",
    FROZEN_SENSOR: "Physically inspect the sensing element for icing, blockage or failure.",
    DRIFT: "Schedule a calibration check against a reference instrument.",
    COMMUNICATION_FAILURE: "Check the datalogger, modem and power supply at the station.",
    MULTIVARIATE_ANOMALY: "Verify channel wiring and the datalogger channel map.",
    UNKNOWN_ANOMALY: "Hold for analyst review before publishing.",
}


class AnomalyExplainer:
    """Produces the full explanation bundle for one diagnosed sample."""

    def __init__(
        self,
        baseline: Baseline,
        shapley: Optional[ShapleyExplainer] = None,
    ):
        self.baseline = baseline
        self.shapley = shapley or ShapleyExplainer(baseline)

    # -- 1. why was it detected? -------------------------------------------

    def why_detected(self, result: RootCauseResult) -> List[str]:
        """Ordered, human-readable rule trace - the audit trail of the decision."""
        reasons = [e.description for e in result.primary.evidence]
        if not reasons:
            record = result.record
            if result.primary.fault == NO_FAULT:
                reasons.append(
                    "No detector exceeded its threshold: the reading is within normal "
                    "limits on every check."
                )
            else:
                reasons.append(
                    f"Statistical detection only (model score {record.ml_anomaly_score:.1f}/100)."
                )
        return reasons

    # -- 2 & 3. feature contributions and SHAP -----------------------------

    def feature_contributions(self, result: RootCauseResult) -> List[FeatureContribution]:
        record = result.record
        if len(record.values) < len(SENSORS):
            return []

        phi = self.shapley.explain(record.values)
        total_abs = sum(abs(v) for v in phi.values()) or 1.0

        # Map rule evidence back onto the channel it came from, so the table
        # shows BOTH the statistical attribution and the rule that fired.
        support: Dict[str, List[str]] = {s: [] for s in SENSORS}
        for ev in result.primary.evidence:
            if ev.sensor:
                support[ev.sensor].append(ev.check)

        contributions: List[FeatureContribution] = []
        for sensor in SENSORS:
            sb = self.baseline.sensors[sensor]
            value = record.values[sensor]
            z = (value - sb.median) / sb.sigma
            contributions.append(
                FeatureContribution(
                    feature=sensor,
                    label=SENSOR_LABEL[sensor],
                    value=value,
                    unit=SENSOR_UNIT[sensor],
                    shap_value=phi[sensor],
                    contribution_pct=100.0 * abs(phi[sensor]) / total_abs,
                    deviation_sigma=z,
                    direction="above" if z > 0.5 else ("below" if z < -0.5 else "at"),
                    rule_support=support[sensor],
                )
            )

        contributions.sort(key=lambda c: abs(c.shap_value), reverse=True)
        return contributions

    # -- detector agreement -------------------------------------------------

    def detector_agreement(self, record: SignalRecord) -> Dict[str, Any]:
        """Which of the three independent modules saw something."""
        ml = bool(record.ml_flag or record.ml_anomaly_score >= 50.0)
        temporal = bool(record.spike_flag or record.drift_flag or record.frozen_flag)
        multivariate = record.multivariate_score >= 0.8

        votes = sum([ml, temporal, multivariate])
        return {
            "ml_model": {
                "fired": ml,
                "score": round(record.ml_anomaly_score, 1),
                "detail": "Isolation Forest, 500 trees",
            },
            "temporal": {
                "fired": temporal,
                "score": round(record.temporal_score, 3),
                "detail": record.temporal_reason or "no temporal rule fired",
            },
            "multivariate": {
                "fired": multivariate,
                "score": round(record.multivariate_score, 3),
                "detail": "joint sensor-consistency score",
            },
            "votes": votes,
            "unanimous": votes == 3,
            "summary": f"{votes} of 3 independent detectors flagged this sample.",
        }

    # -- 4. human-readable explanation -------------------------------------

    def narrative(
        self,
        result: RootCauseResult,
        contributions: List[FeatureContribution],
        agreement: Dict[str, Any],
    ) -> str:
        fault = result.primary.fault
        record = result.record
        when = record.timestamp.strftime("%d %b %Y, %H:%M:%S") if record.timestamp else "this sample"

        if fault == NO_FAULT:
            return (
                f"At {when} the station is operating normally. "
                + FAULT_NARRATIVE[NO_FAULT]
            )

        parts: List[str] = []

        # Opening: what and where.
        sensors = result.primary.affected_sensors
        title = result.primary.title
        if fault == MULTIVARIATE_ANOMALY:
            title = MULTIVARIATE_SUBTYPE_TITLE.get(
                result.primary.details.get("subtype", ""), title)
        if sensors:
            names = ", ".join(SENSOR_LABEL[s] for s in sensors)
            parts.append(
                f"At {when} the system diagnosed a {title.lower()} affecting {names}."
            )
        else:
            parts.append(
                f"At {when} the system diagnosed a {title.lower()} at this station."
            )

        # Mechanism (subtype-aware for multivariate).
        if fault == MULTIVARIATE_ANOMALY:
            subtype = result.primary.details.get("subtype", "cross_variable")
            parts.append(MULTIVARIATE_SUBTYPE_NARRATIVE.get(
                subtype, FAULT_NARRATIVE[MULTIVARIATE_ANOMALY]))
        else:
            parts.append(FAULT_NARRATIVE.get(fault, ""))

        # The single strongest piece of evidence, in the engineer's language.
        if result.primary.evidence:
            strongest = max(result.primary.evidence, key=lambda e: e.strength * e.weight)
            parts.append("The clearest indicator: " + strongest.description)

        # Attribution. Cite the channel the DIAGNOSIS blames, not simply the
        # largest SHAP value: SHAP scores the joint-distance value function, so
        # on a temporal fault (a spike is about the STEP, not the level) the
        # biggest SHAP value can belong to an unrelated channel.
        # Channel attribution is meaningless for a telemetry gap: no sensor
        # "caused" a missing packet, so the sentence is suppressed entirely.
        attribution_meaningful = not (
            fault == COMMUNICATION_FAILURE and not sensors
        )
        if contributions and attribution_meaningful:
            top = contributions[0]
            if sensors:
                for c in contributions:
                    if c.feature in sensors:
                        top = c
                        break
            parts.append(
                f"{top.label} carries {top.contribution_pct:.0f}% of the statistical "
                f"attribution, reading {top.value:.2f} {top.unit} "
                f"({abs(top.deviation_sigma):.1f} sigma {top.direction} its normal level)."
            )
            if sensors and contributions[0].feature not in sensors:
                parts.append(
                    f"Note that the joint-distance attribution is led by "
                    f"{contributions[0].label} instead, because SHAP scores the level of "
                    "each channel while this fault is defined by rate of change."
                )

        # Corroboration.
        parts.append(agreement["summary"])

        # Competing hypothesis, stated openly - unless that hypothesis was
        # demoted precisely BECAUSE this fault explains it. Reporting a
        # side effect as a rival would wrongly imply the diagnosis is shaky.
        demoted_by_primary = (
            result.runner_up is not None
            and result.runner_up.details.get("explained_away_by") == fault
        )
        if result.runner_up and result.runner_up.score >= 0.25 and not demoted_by_primary:
            parts.append(
                f"The next most likely explanation was {result.runner_up.title.lower()} "
                f"(score {result.runner_up.score:.2f} against {result.primary.score:.2f}), "
                "so this diagnosis is not clear-cut."
            )

        # What to do.
        hint = MAINTENANCE_HINT.get(fault)
        if hint:
            parts.append(hint)

        return " ".join(p for p in parts if p)

    # -- technical trace ----------------------------------------------------

    @staticmethod
    def technical_trace(result: RootCauseResult) -> List[Dict[str, Any]]:
        """Full machine-readable audit trail for every hypothesis considered."""
        trace = []
        for candidate in result.candidates:
            trace.append({
                "hypothesis": candidate.fault,
                "score": round(candidate.score, 4),
                "checks": [e.to_dict() for e in candidate.evidence],
                "details": candidate.details,
            })
        return trace

    # -- known limitations, surfaced rather than hidden ---------------------

    def limitations(self, result: RootCauseResult) -> List[str]:
        notes: List[str] = []
        fault = result.primary.fault
        record = result.record

        if fault == FROZEN_SENSOR:
            for sensor in result.primary.affected_sensors:
                sb = self.baseline.sensors[sensor]
                if sb.resolution >= 0.1 and sb.longest_natural_run > 40:
                    notes.append(
                        f"{SENSOR_LABEL[sensor]} is quantised to {sb.resolution:g} "
                        f"{SENSOR_UNIT[sensor]} and naturally holds one value for up to "
                        f"{sb.longest_natural_run} samples, so short freezes on this channel "
                        "cannot be separated from genuinely steady conditions."
                    )
        if fault == DRIFT:
            notes.append(
                "Drift is measured against the training baseline; a genuine seasonal or "
                "diurnal shift in the weather can resemble instrument drift."
            )
        if result.primary.details.get("explained_away_by"):
            notes.append(
                "A competing hypothesis was demoted as a side effect: "
                + str(result.primary.details.get("explain_away_note", ""))
            )
        if record.ml_anomaly_score == 0.0 and fault != NO_FAULT:
            notes.append(
                "No ML score was available for this sample, so the diagnosis rests on the "
                "rule and time-series evidence alone."
            )
        return notes

    # -- public entry point -------------------------------------------------

    def explain(self, result: RootCauseResult) -> Explanation:
        contributions = self.feature_contributions(result)
        agreement = self.detector_agreement(result.record)
        fault = result.primary.fault

        if fault == NO_FAULT:
            headline = "Normal operation"
        else:
            sensors = result.primary.affected_sensors
            title = result.primary.title
            if fault == MULTIVARIATE_ANOMALY:
                title = MULTIVARIATE_SUBTYPE_TITLE.get(
                    result.primary.details.get("subtype", ""), title)
            where = f" on {SENSOR_LABEL[sensors[0]]}" if len(sensors) == 1 else ""
            headline = f"{title}{where}"

        return Explanation(
            headline=headline,
            why_detected=self.why_detected(result),
            feature_contributions=contributions,
            detector_agreement=agreement,
            narrative=self.narrative(result, contributions, agreement),
            technical_trace=self.technical_trace(result),
            shap_method=self.shapley.method,
            shap_efficiency_error=getattr(self.shapley, "last_efficiency_error", 0.0),
            limitations=self.limitations(result),
        )


# --------------------------------------------------------------------------
# Self-test
# --------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    from root_cause import RootCauseAnalyzer, load_baseline, load_csv, records_from_csv

    if len(sys.argv) != 3:
        print("Usage: python explainability.py <train_raw.csv> <signals.csv>")
        raise SystemExit(1)

    baseline = load_baseline(sys.argv[1])
    records = records_from_csv(sys.argv[2])

    background = [
        {s: float(r[s]) for s in SENSORS}
        for r in load_csv(sys.argv[1])[:500]
    ]

    analyzer = RootCauseAnalyzer(baseline)
    results = analyzer.analyze_stream(records)
    explainer = AnomalyExplainer(baseline, ShapleyExplainer(baseline, background=background))

    print(f"SHAP back-end: {explainer.shapley.method}")
    print(f"shap library installed: {ShapleyExplainer.library_available()}\n")

    shown = 0
    worst_error = 0.0
    for result in results:
        exp = explainer.explain(result)
        worst_error = max(worst_error, exp.shap_efficiency_error)
        if result.is_fault and shown < 3:
            shown += 1
            print("=" * 78)
            print(exp.headline)
            print("=" * 78)
            print("\nWHY DETECTED")
            for reason in exp.why_detected:
                print(f"  - {reason}")
            print("\nFEATURE CONTRIBUTIONS")
            for c in exp.feature_contributions:
                bar = "#" * int(c.contribution_pct / 4)
                print(f"  {c.label:<20} {c.value:>9.2f} {c.unit:<6} "
                      f"{c.contribution_pct:>5.1f}%  {bar}")
            print("\nEXPLANATION")
            print(f"  {exp.narrative}")
            if exp.limitations:
                print("\nLIMITATIONS")
                for lim in exp.limitations:
                    print(f"  ! {lim}")
            print()

    print(f"Max Shapley efficiency error across {len(results)} samples: {worst_error:.2e}")
    print("(should be ~1e-12; proves the attribution is complete and exact)")
